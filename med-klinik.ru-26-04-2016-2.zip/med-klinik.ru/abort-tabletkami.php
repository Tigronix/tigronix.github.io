﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Аборт таблетками: мифепристон , пенкрафтон, мифегин. Цена от 7500 рублей</title>
<meta name="description" lang="ru" content="Аборт при помощи таблеток в медклинике на Авиамоторной.Мифепристон , пенкрафтон - 7500 руб., мифегин - 9500 руб. Включено: стоимость препарата, осмотры, УЗИ, мазок на флору и инфекции" />
<meta name="keywords" lang="ru" content="Аборт таблетками" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/medikomentoznyi-abort/">Медикаментозный аборт</a></li> <li>Аборт таблетками</li></ul>
		
		
		
		<div class="rside_txt">
		
		<h1>Аборт таблетками</h1>
		
		<p>Аборт, выполняемый при помощи таблеток - это медикаментозное прерывание, который выполняется не хирургическим способом, а специальными медицинскими препаратами. В нашей клинике доктора имеют высокий уровень квалификации и обладают всеми знаниями и навыками проведения медикаментозного аборта. Наши специалисты наблюдают за состоянием здоровья пациентки и контролируют процесс протекания прерывания беременности на всех его этапах.</p>
		
		<div class="zapis_txt">
			Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
		</div>
		
		<h2>Прием ведут:</h2>

		<table class="tbl_spec tbl_spec_2">
				<tr>
					<td>
						<img src="../images/foto_4.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Букинская<br>
							Елена<br>
							Владимировна
						</div>
						<div class="tbl_spec_dolj">Акушер-гинеколог, врач <br>высшей категории</div>
						<a href="/bukinskaya-elena-vladimirovna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					<td>
						<img src="../images/foto_7.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Петрашко<br>
							Татьяна<br>
							Николаевна
						</div>
						<div class="tbl_spec_dolj">Врач акушер гинеколог, <br>врач высшей категории</div>
						<a href="/petrashko-tatyana-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					
					</tr>
					<tr>
				<td class="center_td">
					<img src="../images/foto_8.png" width="165" height="186" alt="img">
					<div class="tbl_spec_fio">
						Шиленина<br>
						Елена<br>
						Николаевна
					</div>
					<div class="tbl_spec_dolj">Акушер-гинеколог, <br>врач высшей категории</div>
					<a href="/shilenina-elena-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>
		
		<h2>Стоимость услуг:</h2>
		
<table class="tbl_price">
	<thead>
		<tr>
			<td width="603">Медикаментозное прерывание беременности</td>
			<td width="197" align="center">Стоимость услуг</td>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>Анализы перед медикаментозным прерыванием беременности (&beta; – ХГЧ,TPHA, ВИЧ,      гепатит В и С, группа крови и резус фактор )</td>
			<td align="center" class="price">2 000</td>
		</tr>
		<tr>
			<td>Медикаментозное прерывание беременности препаратом Мифепристон(Миропристон) (Россия) (В стоимость входит: консультация, осмотр, 3УЗИ, мазок  на флору и инфекции и стоимость препарата)</td>
			<td align="center" class="price">7 500</td>
		</tr>
		<tr>
			<td>Медикаментозное прерывание беременности препаратом Пенкрафтон (Россия) (В стоимость входит: : консультация, осмотр, 3 УЗИ, мазок  на флору и инфекции и стоимость препарата)</td>
			<td align="center" class="price">7 500</td>
		</tr>
		<tr>
			<td>Медикаментозное прерывание беременности препаратом Мифегин (Франция)(В стоимость входит: : консультация, осмотр 3УЗИ, мазок методом ПИФ на флору и инфекции и стоимость препарата)</td>
			<td align="center" class="price">9 500</td>
		</tr>
	</tbody>
</table>

<p>Аборт, выполняемый при помощи таблетки весьма эффективная процедура, но аборт таблетками даст результаты только на ранних сроках беременности. Медикаментозный аборт менее травматичен нежели хирургический аборт, а реабилитационный период значительно короче.</p>

<p>В нашей клинике используются только те препараты, которые прошли все необходимые исследования и не приносят вреда женскому организму: Пенкрофтон, Мифегин, Мифепристон.</p>

<p><img style="width: 210px; height: 210px; margin: 10px; float: left;" src="../img/Tabletki_dlya_preryvania_beremennosti.jpg" alt="аборт таблетками мифегин" /><img style="width: 210px; height: 210px; margin: 10px; float: left;" src="../img/Penkrofton.jpg" alt="аборт таблетками пенкрофтон" /><img style="width: 210px; height: 210px; margin: 10px; float: left;" src="../img/mifepriston.jpg" alt="аборт таблетками мифепристон" /></p>

<div class="clr"></div>

<p>Подготовка к прерыванию беременности - весьма быстрая процедура, пациентка сдает кровь, мочу, мазок и проходит ультразвуковое обследование. После этого доктор разъясняет женщине все плюсы и минусы, которые влечет за собой такой аборт, после чего пациентка подписывает документ о согласии проведения медикаментозного прерывания. Это первый этап. Вторым этапом будет, то что женщина в присутствии врача принимает назначенный препарат и еще два часа наблюдается в поликлинике, далее женщина может идти домой, но в течении последующих 36-48 часов пациентке необходимо вернутся в клинику, где под пристальным присмотром доктора женщина выпивает простагландин и так же наблюдается еще несколько часов, так как в этот период усиливается кровотечение и происходит выталкивание плодного яйца из полости матки. Следующий визит к доктору должен состояться через8-14 дней после того как проведен аборт, доктор проанализирует ваше состояние и проведет ультразвуковое обследование, для того, что б убедиться, что полость матки полностью чиста.</p>

<p>При медикаментозном прерывании беременности женщине не нужно соблюдать постельный режим, кровянистые выделения прекратятся, где то через две недели после проведения процедуры. Также сразу после прекращения кровотечений вам необходимо принимать оральные контрацептивы, прописанные доктором, дабы избежать нежелательной беременности и вытекающих последствий. Если по какой-то причине вам необходимо сделать медикаментозный аборт приходите в нашу клинику и наши специалисты помогут вам в этой ситуации и проведут аборт таблетками безопасно и без вреда для здоровья.</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
<li><a href="/vedenie-beremennosti-ceny/">Беременность</a>, 
	<a href="/lecheniye-bakterialnogo-vaginoza/">Вагиноз</a>, 
	<a href="/bartolinit/">Бартолинит</a>, 
	<a href="/salpingooforit-adneksit/">Аднексит</a>, 
	<a href="/endometrit-metroendometrit/">Эндометрит</a>, 
	<a href="/endocervicit/">Эндоцервицит</a>, 
	<a href="/endometrioz/">Эндометриоз</a>, 
	<a href="/eroziya-sheiki-matki/">Эрозия шейки матки</a>, 
	<a href="/infekcii-zhenskoi-polovoi-sistemy/">Инфекции женской половой системы</a>, 
	<a href="/proyavlenie-gormonalnyh-narushenii/">Гормональные нарушения</a>, 
	<a href="/diagnostika-besplodiya/">Бесплодие</a>, 
	<a href="/klimaks/">Климакс</a>, 
	<a href="/narushenie-menstrualnogo-cikla/">Нарушение менструального цикла</a>, 
	<a href="/kontracepciya/">Контрацепция</a>, 
	<a href="/medikomentoznyi-abort/">Медикаментозный аборт </a>
</li>
<li><a href="/diagnostika-bakterialnogo-vaginoza/">Диагностика бактериального вагиноза</a>, 
	<a href="/etiologiya-bakterialnogo-vaginoza/">Этиология бактериального вагиноза</a>, 
	<a href="/zarazhenie-bakterialnym-vaginozom/">Заражение бактериальным вагинозом</a>, 
	<a href="/klinika-bakterialnogo-vaginoza/">Клиника бактериального вагиноза</a>, 
	<a href="/bakterialnyi-vaginoz-oslozhneniya/">Бактериальный вагиноз - осложнения </a>
</li>
<li><a href="/prichiny-gormonalnyh-narushenii/">Причины гормональных нарушений</a>, 
	<a href="/lechenie-i-diagnostika-gormonalnyh-narushenii/">Лечение и диагностика гормональных нарушений </a>
</li>
<li><a href="/lecheniye-besplodiya-v-moskve/">Лечение бесплодия</a>, 
	<a href="/lecheniye-zhenskogo-besplodiya/">Лечение женского бесплодия</a>
</li>
<li>
	<a href="/farmabort/">Фармаборт</a>, 
	<a href="/bezoperacionnyi-abort/">Безоперационный аборт</a>, 
</li>

</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>