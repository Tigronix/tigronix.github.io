﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Цитологическое исследование</title>
<meta name="description" lang="ru" content="Цитологическое исследование" />
<meta name="keywords" lang="ru" content="Цитологическое исследование" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/sdat-analizy/">Анализы</a></li> <li>Цитологическое исследование</li></ul>
		
		
		
		<div class="rside_txt">
		
			
	        		<h1>Цитологическое исследование</h1>
					
					
					<p>Цитология – это целый ряд лабораторных исследований, которые проводятся на основе клеточных элементов. Этот метод широко распространен в гинекологической практике для проведения оценки тканей в шейке  матки, влагалища и цервикального канала.</p>

<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>
		
<h2>Стоимость услуг:</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость услуг</td>
	</tr>
</thead>
	<tbody>
		<tr>
			<td colspan="4">Анализы</td>
		</tr>
		<tr>
			<td>Цитологическое исследование</td>
			<td align="center" class="price">1 570 руб.</td>
		</tr>
	</tbody>
</table>




<p>Забор материала осуществляется особым пластиковым зондом. Таким образом, необходимый материал для проведения исследований врач получает одновременно и из влагалища, и из матки, и из цервикального канала. Точно такой же зонд используют и для заборе клеток из слизистой оболочки влагалища. В некоторых случаях при проведении забора материала требуется контроль кальпоскопа.</p>

<p>Также в некоторых случаях для проведения цитологического анализа необходимо жидкий материал. Тогда берут мазок-отпечаток или же засасывают материал в шприц. через отверстие в игле Для проведения анализа полученный результат сушат, фиксируют и маркируют. В лабораторных условиях проводят исследования по различным методикам.</p>

<p>Перед проведением забора материала, необходимого для исследования необходимо придерживаться следующих правил:</p>

<p>- исключить половые контакты за два-три дня до забора;</p>

<p>- исключить прием контрацептивных препаратов за два-три дня до забора, а также использование различных свечей, мазей применяемых во влагалище;</p>

<p>- анализ проводят сразу после окончания менструации;</p>

<p>- если у пациента наблюдается наличие кровяных выделений из влагалища делать забор материала нельзя;</p>

<p>- во время приема антибиотиков, антимикробных и внутривлагалищных препаратов процедура не проводится;</p>

<p>- забор клеток проводят только по прохождении 2-3 дней после проведения расширенной кальпоскопии.</p>

<p>Результат цитологического исследования будет готов уже через несколько суток. В некоторых случаях врач может назначить экспресс-цитологию. Это значит, что необходимо оперативное лечение, а результат анализа будет готов к анализу уже через несколько минут.</p>

<p>Этот метод является надежным показателем слизистой влагалища и шейки матки, особенно если есть подозрения на опухоль.</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li><a href="/sdat-analizy/">Анализы</a></li>

	<li>
	<a href="/obsledovaniye-na-ippp/">ПЦР-диагностика</a>, 
	<a href="/analizy-na-polovyye-infektsii/">Анализы на половые инфекции</a>, 
	<a href="/analizy-na-infekcii-u-zhenshchin/">Анализы на инфекции у женщин</a>, 
	<a href="/analizy-na-infektsii-u-muzhchin/">Анализы на инфекции у мужчин</a>, 
	<a href="/analizy-na-gormony/">Анализы на гормоны</a>, 
	<a href="/analizy-anonimno/">Анализы анонимно</a>
	</li>

	<li>
	<a href="/analizy-krovi/">Анализ крови</a>, 
	<a href="/analiz-mochi/">Анализ мочи</a>, 
	<a href="/mikroskopiya/">Микроскопия крови</a>, 
	<a href="/mikrobiologiya/">Микробиологические исследования</a>, 
	<a href="/gistologiya/">Гистология</a>
	</li>
</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>