﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Этиология гонореи</title>
<meta name="description" lang="ru" content="Этиология гонореи" />
<meta name="keywords" lang="ru" content="Этиология гонореи" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/lecheniye-gonorei/">Гонорея</a></li> <li>Этиология гонореи</li></ul>
		
		
		
		<div class="rside_txt">
		
			
	        		<h1>Этиология гонореи</h1>

<div class="doc_info">
			
						<table class="tbl_doc_info">
							<tbody><tr>
								<td width="469">
									<img src="../images/foto_3.png" width="165" height="186" alt="img">
									<div class="tbl_spec_fio">
										Диденко<br />
Елена<br />
Юрьевна
									</div>
									<div class="tbl_spec_dolj">Дерматовенеролог, уролог, андролог.<br>Врач 1 категории</div>
								</td>
								<td width="333" class="tbl_doc_info_right">
									<span class="bold">Записаться на прием можно:</span><br>
									
									На сайте:
									
									<div class="arrow_bot"></div>
									
									<span class="btn_zapis_wrap">
										<a href="/zayavka/" class="btn_zapis">Онлайн запись на прием</a>
									</span>
									<div class="tbl_doc_info_contact">
										По телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
									</div>
								</td>
							</tr>
						</tbody></table>
					
					</div>
					
<p>Возбудителем <a href="/lecheniye-gonorei/">гонореи</a> является Neisseria gonorrhoeae - грамотрицательный диплококк, имеющий форму кофейных зёрен, обращенных своей вогнутой поверхностью друг к другу. Гонококки имеют хорошо выраженные трёхслойную наружную стенку и цитоплазматическую мембрану, цитоплазму с рибосомами и ядерной вакуолью.<br />
<br />
 Гонококки обычно располагаются внутриклеточно, в протоплазме лейкоцитов, обычно группами, но иногда можно видеть и внеклеточных гонококков. Исследования гонококков в последние годы указывают на изменения их биологических свойств (наличие капсул, фагосом, влактамазы, снижение чувствительности к антибиотикам, появление L-форм).<br />
<br />
 Гонококки поражают слизистые оболочки, с частности мочеиспускательного канала, влагалища, прямой кишки, полостей рта, носа, гортани. Процесс может распространяться на предстательную железу, семенные пузырьки, придатки яичек, яичко, семявыносящие протоки, а у женщин — на матку, яичники, маточные трубы.<br />
<br />
 Распространяясь по кровяному руслу, гонококки могут иногда вызывать гонококковый сепсис и метастазы в различные органы. При гонококковой бактериемии поражаются суставы, глаза, плевра, эндокард, мышцы, кости, нервы. У новорождённых поражаются глаза, развиваются конъюнктивит, кератит.</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li><a href="/priem-dermatologa/">Консультация венеролога</a>
		</li>
	<li><a href="/diagnostika-kandidoza/">Кандидоз</a>, 
		<a href="/lecheniye-kandidoza-v-moskve/">Лечение кандидоза</a>, 
		<a href="/epidemiologiya-kandidoza/">Эпидемиология кандидоза</a>, 
		<a href="/klinika-kandidoza/">Клиника кандидоза</a>
		</li>
	<li><a href="/lechenie-mikoplazmoza/">Микоплазмоз</a>
		</li>
	<li><a href="/lecheniye-khlamidioza-v-moskve/">Хламидиоз</a>, 
		<a href="/diagnostika-khlamidioza/">Диагностика хламидиоза</a>, 
		<a href="/lecheniye-khlamidioza-u-zhenshchin/">Лечение хламидиоза у женщин</a>, 
		<a href="/lecheniye-khlamidioza-u-muzhchin/">Лечение хламидиоза у мужчин</a>
		</li>
	<li><a href="/diagnostika-gerpesa/">Генитальный герпес</a>, 
		<a href="/lecheniye-genitalnogo-gerpesa/">Лечение генитального герпеса</a>, 
		<a href="/etiologiya-gerpesa/">Этиология герпеса</a>
		</li>
	<li><a href="/lecheniye-ureaplazmoza-u-zhenshchin/">Уреаплазмоз</a>
		</li>
	<li><a href="/lecheniye-papillomavirusa/">Папилломавирус</a>, 
		<a href="/diagnostika-vpch/">Диагностика ВПЧ</a>
		</li>
	<li><a href="/lechenie-trihomoniaza/">Трихомониаз</a>, 
		<a href="/diagnostika-trikhomoniaza/">Диагностика трихомониаза</a>
		</li>
	<li><a href="/lecheniye-gonorei/">Гонорея</a>, 
		<a href="/diagnostika-gonorei/">Диагностика гонореи</a>, 
		<a href="/lecheniye-gonorei-u-muzhchin/">Лечение гонореи у мужчин</a>, 
		<a href="/lecheniye-gonorei-u-zhenshchin/">Лечение гонореи у женщин</a>, 
		<a href="/gonoreya-u-detei/">Гонорея у детей</a>
		</li>
	<li><a href="/sifilis/">Сифилис</a>, 
		<a href="/etiologiya-sifilisa/">Этиология сифилиса</a>, 
		<a href="/puti-zarazheniya/">Пути заражения</a>, 
		<a href="/pervichnyi-period-sifilisa/">Первичный период сифилиса</a>, 
		<a href="/vtorichnyi-period-sifilisa/">Вторичный период сифилиса</a>, 
		<a href="/tretichnyi-period-sifilisa/">Третичный период сифилиса</a>, 
		<a href="/skrytyi-sifilis/">Скрытый сифилис</a>, 
		<a href="/neirosifilis/">Нейросифилис</a>, 
		<a href="/viscerosifilis/">Висцеросифилис</a>, 
		<a href="/vrozhdennyi-sifilis/">Врожденный сифилис</a>, 
		<a href="/diagnostika-sifilisa/">Диагностика сифилиса</a>
		</li>
	<li>
		<a href="/vich/">ВИЧ</a>
	</li>	
</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>