﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Этиология сифилиса</title>
<meta name="description" lang="ru" content="Этиология сифилиса" />
<meta name="keywords" lang="ru" content="Этиология сифилиса" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/sifilis/">Сифилис</a></li> <li>Этиология сифилиса</li></ul>
		
		
		
		<div class="rside_txt">
		
			
	        		<h1>Этиология сифилиса</h1>

<div class="doc_info">
			
						<table class="tbl_doc_info">
							<tbody><tr>
								<td width="469">
									<img src="../images/foto_3.png" width="165" height="186" alt="img">
									<div class="tbl_spec_fio">
										Диденко<br />
Елена<br />
Юрьевна
									</div>
									<div class="tbl_spec_dolj">Дерматовенеролог, уролог, андролог.<br>Врач 1 категории</div>
								</td>
								<td width="333" class="tbl_doc_info_right">
									<span class="bold">Записаться на прием можно:</span><br>
									
									На сайте:
									
									<div class="arrow_bot"></div>
									
									<span class="btn_zapis_wrap">
										<a href="/zayavka/" class="btn_zapis">Онлайн запись на прием</a>
									</span>
									<div class="tbl_doc_info_contact">
										По телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
									</div>
								</td>
							</tr>
						</tbody></table>
						
					</div>
					
<p><span class="bold">Возбудитель сифилиса - бледная трепонема (Treponema pallidum)</span>.  Типичные бледные трепонемы представляют собой тонкие спиралевидные микроорганизмы длиной 6 - 14 мкм, толщиной 0,25 - 0,30 мкм, с амплитудой спирали 0,5 - 1,0 мкм. Завитки спирали расположены на равном расстоянии друг от друга. Трепонемы очень подвижны и постоянно вращаются вокруг продольной оси, иногда изгибаясь и образуя почти замкнутый круг.<br />
<br />
 Для выявления бледных трепонем используют тёмное поле микроскопа или иммунофлюоресцентную окраску. Бледные трепонемы плохо окрашиваются анилиновыми красителями. С помощью электронной микроскопии установлено, что бледная трепонема снаружи покрыта чехлом, под которым находятся трёхслойная наружная стенка и цитоплазматическая мембрана. Она имеет поверхностные и глубокие фибриллы, способствующие движению.</p>

<p>Трепонемы обычно размножаются поперечным делением. В специальном растворе и в присутствии редуцирующих веществ бледные трепонемы сохраняют подвижность при 25°С в течение 3 - 6 дней. В цельной крови или в сыворотке при 4°С микроорганизмы сохраняют жизнеспособность не менее 24 часов, что имеет значение при переливании крови.<br />
<br />
 Трепонемы быстро погибают при высушивании и повышении температуры до 42°С. Они мгновенно теряют подвижность и погибают в присутствии соединений мышьяка, ртути, висмута. В целом, однако, бледные трепонемы погибают очень медленно. Объясняется это низкой метаболической активностью и замедленным размножением этих бактерий (время деления составляет около 30 часов). При неблагоприятных условиях существования (воздействие антибиотиков, недостаток питания) трепонемы могут образовывать "формы выживания" - цисты и L-формы.</p>

<p>В организме человека трепонемы стимулируют выработку антител, способных окрашивать бледную трепонему при использовании непрямого метода флюоресцирующих антител; вызывать иммобилизацию и гибель живых подвижных бледных трепонем; связывать комплемент в присутствии суспензии трепонем.</p>

<p>Трепонемы вызывают также выработку антителоподобного вещества (реагина), которое даёт положительную реакцию связывания комплемента (РСК) и реакцию флоккуляции с водными суспензиями липидов, экстрагированных из нормальных тканей млекопитающих. Как реагины, так и противоспирохетные антитела могут быть использованы для серодиагностики сифилиса.</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li><a href="/priem-dermatologa/">Консультация венеролога</a>
		</li>
	<li><a href="/diagnostika-kandidoza/">Кандидоз</a>, 
		<a href="/lecheniye-kandidoza-v-moskve/">Лечение кандидоза</a>, 
		<a href="/epidemiologiya-kandidoza/">Эпидемиология кандидоза</a>, 
		<a href="/klinika-kandidoza/">Клиника кандидоза</a>
		</li>
	<li><a href="/lechenie-mikoplazmoza/">Микоплазмоз</a>
		</li>
	<li><a href="/lecheniye-khlamidioza-v-moskve/">Хламидиоз</a>, 
		<a href="/diagnostika-khlamidioza/">Диагностика хламидиоза</a>, 
		<a href="/lecheniye-khlamidioza-u-zhenshchin/">Лечение хламидиоза у женщин</a>, 
		<a href="/lecheniye-khlamidioza-u-muzhchin/">Лечение хламидиоза у мужчин</a>
		</li>
	<li><a href="/diagnostika-gerpesa/">Генитальный герпес</a>, 
		<a href="/lecheniye-genitalnogo-gerpesa/">Лечение генитального герпеса</a>, 
		<a href="/etiologiya-gerpesa/">Этиология герпеса</a>
		</li>
	<li><a href="/lecheniye-ureaplazmoza-u-zhenshchin/">Уреаплазмоз</a>
		</li>
	<li><a href="/lecheniye-papillomavirusa/">Папилломавирус</a>, 
		<a href="/diagnostika-vpch/">Диагностика ВПЧ</a>
		</li>
	<li><a href="/lechenie-trihomoniaza/">Трихомониаз</a>, 
		<a href="/diagnostika-trikhomoniaza/">Диагностика трихомониаза</a>
		</li>
	<li><a href="/lecheniye-gonorei/">Гонорея</a>, 
		<a href="/diagnostika-gonorei/">Диагностика гонореи</a>, 
		<a href="/lecheniye-gonorei-u-muzhchin/">Лечение гонореи у мужчин</a>, 
		<a href="/lecheniye-gonorei-u-zhenshchin/">Лечение гонореи у женщин</a>, 
		<a href="/gonoreya-u-detei/">Гонорея у детей</a>, 
		<a href="/etiologiya-gonorei/">Этиология гонореи</a>
		</li>
	<li><a href="/sifilis/">Сифилис</a>, 
		<a href="/puti-zarazheniya/">Пути заражения</a>, 
		<a href="/pervichnyi-period-sifilisa/">Первичный период сифилиса</a>, 
		<a href="/vtorichnyi-period-sifilisa/">Вторичный период сифилиса</a>, 
		<a href="/tretichnyi-period-sifilisa/">Третичный период сифилиса</a>, 
		<a href="/skrytyi-sifilis/">Скрытый сифилис</a>, 
		<a href="/neirosifilis/">Нейросифилис</a>, 
		<a href="/viscerosifilis/">Висцеросифилис</a>, 
		<a href="/vrozhdennyi-sifilis/">Врожденный сифилис</a>, 
		<a href="/diagnostika-sifilisa/">Диагностика сифилиса</a>
		</li>
	<li>
		<a href="/vich/">ВИЧ</a>
	</li>	
</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>