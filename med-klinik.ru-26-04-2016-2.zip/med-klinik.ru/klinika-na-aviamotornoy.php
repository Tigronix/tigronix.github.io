﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Клиника на Авиамоторной, медцентр на авиамоторной</title>
<meta name="description" content="Клиника на Авиамоторной, медцентр на авиамоторной">
<meta name="keywords" content="Клиника на Авиамоторной, медцентр на авиамоторной"><meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Клиника на Авиамоторной</div>
		
		<ul class="pw">
			<li><a href="/">Главная</a></li>
			<li>О медцентре</li>
		</ul><!--/pw-->
		
		
		
		<div class="rside_txt">
		
			<img src="http://www.med-klinik.ru/images/fot_1.png" width="221" height="201" alt="img" />
			
			<p>Наш медцентр на Авиамоторной на рынке платных медицинских услуг с 1998 года. Специалисты многопрофильной клиники осуществляют диагностику и лечение различных заболеваний, в том числе <a href="/lecheniye-prostatita-v-moskve/">лечение простатита</a>, <a href="#">бесплодия</a>, а также заболеваний, передающих половым путем. В спектр наших услуг входит ведение беременности, <a href="/uzi/">ультразвуковая диагностика УЗИ</a>, радиоволновая хирургия и многое другое.</p>
			
			<p>Медцентр на Авиамоторной был открыт два года назад. Сегодня это отделение располагает самым современным оборудованием, используемым для <br />диагностики и лечения, что позволяет оказывать услуги на высоком уровне.</p>
			
			<p>В медицинском центре на Авиамоторной прием ведут <a href="/nashi-specialisty/">опытные специалисты</a>: акушеры-гинекологи, урологи,
андрологии, дерматологи, терапевты и др. специалисты. Врачи высшей категории, кандидаты медицинских наук. 
Профессиональное лечение бесплодия и различных заболеваний половой сферы осуществляется с использованием новейших медицинских методик и препаратов по индивидуальным программам лечения.</p>

			<p>Мы предлагаем нашим пациентам полную и точную диагностику заболеваний .
Медицинский центр на Авиамоторной сотрудничает с ведущими медицинскими научно-исследовательскими организациями и диагностическими лабораториями Москвы. Широкая диагностическая база, индивидуальный подход
и неравнодушное отношение медицинского персонала, позволяет нам в кратчайшие сроки поставить диагноз и назначить лечение. Залогом быстрого выздоровления является не только качественная диагностика и назначение эффективных лекарств, но и внимательное отношение к каждому пациенту.</p>

			<p>В нашем отделении на Авиамоторной создана доброжелательная и спокойная атмосфера, которая позволяет каждому посетителю чувствовать себя комфортно в ожидании приема и в кабинете у врача.
Наш медицинский центр работает каждый день с 9-00 до 21-00 (по будням) и с 9-00 до 19-00 (в выходные),
поэтому вы сможете выбрать для визита к врачу наиболее удобное время.</p>
		
		</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>