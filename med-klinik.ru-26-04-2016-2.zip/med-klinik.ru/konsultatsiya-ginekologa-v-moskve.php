﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Консультация гинеколога в Москве - прием гинеколога цена от 1000 рублей</title>
<meta name="description" lang="ru" content="Консультации врачей-гинекологов высшей категории и все виды обследований в медклинике на Авиамоторной. Первичный прием гинеколога - 1000 руб. Запись на прием гинеколога  +7 (495) 256-38-00" />
<meta name="keywords" lang="ru" content="Консультация гинеколога в Москве, прием гинеколога, консультация гинеколога" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a> </li> <li>Консультация гинеколога</li></ul>
		
		
		
		<div class="rside_txt">
		
			
	        		<h1>Консультация гинеколога в Москве</h1>

<div class="zapis_txt">
			Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
		</div>
		
		<h2>Прием ведут:</h2>

		<table class="tbl_spec tbl_spec_2">
				<tr>
					<td>
						<img src="../images/foto_4.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Букинская<br>
							Елена<br>
							Владимировна
						</div>
						<div class="tbl_spec_dolj">Акушер-гинеколог, врач <br>высшей категории</div>
						<a href="/bukinskaya-elena-vladimirovna/" class="tbl_spec_more">Онлайн консультация</a> 
					</td>
					<td>
						<img src="../images/foto_7.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Петрашко<br>
							Татьяна<br>
							Николаевна
						</div>
						<div class="tbl_spec_dolj">Врач акушер гинеколог, <br>врач высшей категории</div>
						<a href="/petrashko-tatyana-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a> 
					</td>
					
					</tr>
					<tr>
				<td class="center_td">
					<img src="../images/foto_8.png" width="165" height="186" alt="img">
					<div class="tbl_spec_fio">
						Шиленина<br>
						Елена<br>
						Николаевна
					</div>
					<div class="tbl_spec_dolj">Акушер-гинеколог, <br>врач высшей категории</div>
					<a href="/shilenina-elena-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a> 
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>

<h2>Стоимость консультации гинеколога в Москве</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>

	<tbody>
		
		<tr>
			<td colspan="2">Гинекология</td>
		</tr>
		<tr>
			<td>Прием и первичная консультация гинеколога</td>
			<td align="center" class="price"><span class="red_txt">1 000-00</span> </td>
		</tr>
		<tr>
			<td>Повторный осмотр</td>
			<td align="center" class="price">800-00</td>
		</tr>
		<tr>
			<td>Прием и первичная / повторная конс-ция гинеколога - эндокринолога</td>
			<td align="center" class="price">1 000-00 / 800-00</td>
		</tr>
		<tr>
			<td>Прием  врача по контрацепции</td>
			<td align="center" class="price">1 000-00</td>
		</tr>
		<tr>
			<td>Прием  врача по планированию беременности</td>
			<td align="center" class="price">2 000-00</td>
		</tr>
		<tr>
			<td>Прием врача по беременности</td>
			<td align="center" class="price">2 000-00</td>
		</tr>
		<tr>
			<td>Прием врача по заполнению обменной карты</td>
			<td align="center" class="price">5 000-00</td>
		</tr>
		<tr>
			<td>Оформление листа нетрудоспособности</td>
			<td align="center" class="price">1 000-00</td>
		</tr>
		<tr>
			<td>Продление листа нетрудоспособности</td>
			<td align="center" class="price">500-00</td>
		</tr>
		<tr>
			<td>Оформление листа нетрудоспособности 140 дн.</td>
			<td align="center" class="price">5 000-00</td>
		</tr>
		<tr>
			<td valign="top">&nbsp;</td>
			<td></td>
		</tr>
	</tbody>
</table>



<p><span class="bold">Боли в области органов малого таза</span>. Если Вы испытываете резкие или тянущие боли внизу живота, Вам нужна срочная помощь, которую может оказать гинеколог. Перечисленные симптомы могут свидетельствовать о разрыве кисты яичника, воспалении придатков или матки и других опасных для жизни и здоровья состояниях, диагностировать которые может только врач.</p>

<p><img style="width: 340px; height: 185px; margin: 10px; float: left;" src="../img/vospalenie-pridatkov1.jpg" alt="прием гинеколога воспаление придатков" /><img style="width: 340px; height: 185px; margin: 10px; float: left;" src="../img/cyst.jpg" alt="консультация гинеколога в москве киста" /></p>

<div class="clr"></div>

<p><span class="bold">Нарушения менструального цикла</span>. Если Вы страдаете болями в период менструальных кровотечений, отсутствием менструаций или заметили сбои менструального цикла, нужно чтобы Вас проконсультировал гинеколог. На консультации будет проведено комплексное обследование, которое поможет выявить причину недомогания. Ведь Ваши жалобы могут быть симптомами воспалительных процессов, инфекционных заболеваний, гормональных нарушений, эндометриоза, доброкачественных и злокачественных образований и др.</p>

<p><img class="img_center" style="width: 500px; height: 259px; margin: 10px;" src="../img/TMP134-1024x531.jpg" alt="консультация гинеколога при нерегулярном цикле" /></p>

<div class="clr"></div>

<h2>Рекомендуем записаться на прием</h2>

<p>Наша клиника находится по адресу: шоссе Энтузиастов, д. 11А, корп. 3</p>

<p><span class="bold">Подозрение на  инфекцию</span>. Если у Вас был незащищенный половой контакт, после которого Вы заметили неспецифические выделения из влагалища, зуд, жжение или высыпания на коже и половых органах, Вам требуется срочная консультация специалиста. Такие симптомы могут быть вызваны вирусами (герпес, папилломовирус и др.), инфекциями передаваемыми половым путем (хламидиями, микоплазмами, уреаплазмами  и др.). Для диагностики заболевания врач проведет осмотр и назначит необходимые  анализы.</p>

<p><span class="bold">Длительная невозможность зачатия</span>. Если Вы не можете забеременеть более 6 месяцев без использования контрацептивов, вам может потребоваться консультация и прием гинеколога. Консультации и прием гинеколога, а также своевременная диагностика причин бесплодия – гарантия эффективности терапии. Необходимо записаться к гинекологу, который подберет необходимые диагностические методики и назначит лечебные процедуры.</p>

<p><span class="bold">При планировании беременности вам нужны консультации специалиста</span>. Если Вы планируете завести ребенка, обратитесь к гинекологу. На предварительном приеме врач исследует анамнез, проведет физикальный осмотр и назначит необходимые диагностические процедуры. На основе полученных данных врач подберет оптимальный период для зачатия.</p>

		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
<li><a href="/vedenie-beremennosti-ceny/">Беременность</a>, 
	<a href="/lecheniye-bakterialnogo-vaginoza/">Вагиноз</a>, 
	<a href="/bartolinit/">Бартолинит</a>, 
	<a href="/salpingooforit-adneksit/">Аднексит</a>, 
	<a href="/endometrit-metroendometrit/">Эндометрит</a>, 
	<a href="/endocervicit/">Эндоцервицит</a>, 
	<a href="/endometrioz/">Эндометриоз</a>, 
	<a href="/eroziya-sheiki-matki/">Эрозия шейки матки</a>, 
	<a href="/infekcii-zhenskoi-polovoi-sistemy/">Инфекции женской половой системы</a>, 
	<a href="/proyavlenie-gormonalnyh-narushenii/">Гормональные нарушения</a>, 
	<a href="/diagnostika-besplodiya/">Бесплодие</a>, 
	<a href="/klimaks/">Климакс</a>, 
	<a href="/narushenie-menstrualnogo-cikla/">Нарушение менструального цикла</a>, 
	<a href="/kontracepciya/">Контрацепция</a>, 
	<a href="/medikomentoznyi-abort/">Медикаментозный аборт </a>
</li>
<li><a href="/diagnostika-bakterialnogo-vaginoza/">Диагностика бактериального вагиноза</a>, 
	<a href="/etiologiya-bakterialnogo-vaginoza/">Этиология бактериального вагиноза</a>, 
	<a href="/zarazhenie-bakterialnym-vaginozom/">Заражение бактериальным вагинозом</a>, 
	<a href="/klinika-bakterialnogo-vaginoza/">Клиника бактериального вагиноза</a>, 
	<a href="/bakterialnyi-vaginoz-oslozhneniya/">Бактериальный вагиноз - осложнения </a>
</li>
<li><a href="/prichiny-gormonalnyh-narushenii/">Причины гормональных нарушений</a>, 
	<a href="/lechenie-i-diagnostika-gormonalnyh-narushenii/">Лечение и диагностика гормональных нарушений </a>
</li>
<li><a href="/lecheniye-besplodiya-v-moskve/">Лечение бесплодия</a>, 
	<a href="/lecheniye-zhenskogo-besplodiya/">Лечение женского бесплодия</a>
</li>
<li>
	<a href="/farmabort/">Фармаборт</a>, 
	<a href="/bezoperacionnyi-abort/">Безоперационный аборт</a>, 
	<a href="/abort-tabletkami/">Аборт таблеткам</a>
</li>

</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>