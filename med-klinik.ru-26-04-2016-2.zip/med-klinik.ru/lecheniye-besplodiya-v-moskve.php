﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Лечение бесплодия в Москве - цена программы обследования 13210 рублей - Медицинская клиника на Авиамоторной</title>
<meta name="description" lang="ru" content="Диагностика и лечение женского и мужского бесплодия, ЭКО, осмотр маммолога, ведение беременности. Цены. Контакты.Запись на прием +7 (495) 256-38-00" />
<meta name="keywords" lang="ru" content="Лечение бесплодия, лечение бесплодия в москве" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/diagnostika-besplodiya/">Бесплодие</a></li> <li>Лечение бесплодия</li></ul>
		
		
		
		<div class="rside_txt">
		
<h1>Лечение бесплодия в Москве</h1>

<p>Супружеская пара считается бесплодной, если беременность не наступает в течение 1 года регулярной половой жизни, именно тогда необходимо лечение бесплодия в Москве. Наличием бесплодия страдает примерно 8% семейных пар. Обычно, если есть бесплодие, первой за медицинской помощью обращается женщина. Однако установлено, что 40-50% бездетных браков – результат нарушений или бесплодия в мужском организме, и партнер нуждается в лечении. Бесплодие лечится специалистами на основании причин его возникновения и факторов риска при бесплодии.</p>


<div class="zapis_txt">
			Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
		</div>
		
		<h2>Прием ведут:</h2>

		<table class="tbl_spec tbl_spec_2">
				<tr>
					<td>
						<img src="../images/foto_4.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Букинская<br>
							Елена<br>
							Владимировна
						</div>
						<div class="tbl_spec_dolj">Акушер-гинеколог, врач <br>высшей категории</div>
						<a href="/bukinskaya-elena-vladimirovna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					<td>
						<img src="../images/foto_7.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Петрашко<br>
							Татьяна<br>
							Николаевна
						</div>
						<div class="tbl_spec_dolj">Врач акушер гинеколог, <br>врач высшей категории</div>
						<a href="/petrashko-tatyana-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					
				</tr>
					<tr>
				<td class="center_td">
					<img src="../images/foto_8.png" width="165" height="186" alt="img">
					<div class="tbl_spec_fio">
						Шиленина<br>
						Елена<br>
						Николаевна
					</div>
					<div class="tbl_spec_dolj">Акушер-гинеколог, <br>врач высшей категории</div>
					<a href="/shilenina-elena-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>

<h2>Стоимость услуг. Диагностика бесплодия и лечение.</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>

	<tbody>
		
		<tr>
			<td colspan="2">Гинекология</td>
		</tr>
		<tr>
			<td>гинеколог  (первичная консультация)</td>
			<td class="price" align="center"><span class="red_txt">1 000</td>
		</tr>
		<tr>
			<td>Гинеколог - прием (повторная консультация)</td>
			<td class="price" align="center">800</td>
		</tr>
		<tr>
			<td>Гинеколог - эндокринолог (прием и первичная / повторная конс)</td>
			<td class="price" align="center">1 000 / 800</td>
		</tr>
		<tr>
			<td>Прием  врача по планированию беременности</td>
			<td class="price" align="center">2 000</td>
		</tr>
		<tr class="tbl_price_thead">
			<td colspan="2">Диагностика в гинекологии</td>
			</tr>
		<tr>
			<td>Расширенная кольпоскопия со снимками</td>
			<td class="price" align="center">1 500</td>
		</tr>
		<tr>
			<td>Исследование мазков на флору</td>
			<td class="price" align="center">450</td>
		</tr>
		<tr>
			<td>Исследование мазков на бак.посев</td>
			<td class="price" align="center">От 620</td>
		</tr>
		<tr>
			<td>Исследование мазков  ПЦР-анализ (1 инф)</td>
			<td class="price" align="center">240</td>
		</tr>
		<tr>
			<td>Исследование мазков на онкоцитологию (экзо- и эндоцервикс)</td>
			<td class="price" align="center">1 500</td>
		</tr>
		<tr>
			<td>Программа обследования при женском бесплодии</td>
			<td class="price" align="center">1 3210</td>
		</tr>
		<tr>
			<td>Лечение бесплодия воспалительного генеза</td>
			<td class="price" align="center">от  4 500</td>
		</tr>
	</tbody>
</table>




<p><img class="img_center" style="width: 500px; height: 375px; margin: 10px;" src="../img/lechenie-besplodiya1.jpg" alt="лечение бесплодия в москве" /></p>

<div class="clr"></div>

<p><span class="bold">Способы восстановления репродуктивной функции, профилактика бесплодия и лечение бесплодия.</span></p>

<p>Если есть проблемы бесплодия, результаты лечения  зависят от подходов, позволяющих женщине забеременеть, но в дальнейшем пара остается бесплодной. Мужские и женские заболевания преодолеваются путем достижения временного эффекта (например, за счет гормональных препаратов) или использования вспомогательных технологий (таких как экстракорпоральное оплодотворение).</p>

<p>У женщины или мужчины восстанавливается способность иметь детей - лечение бесплодия проходит успешно. В зависимости от диагноза, т.е. причины нарушений, бесплодие можно лечить хирургическим восстановлением функций мужских или женских половых органов. Лечение также может быть медикаментозным либо физиотерапевтическим по воздействию.</p>

<p><img style="width: 350px; height: 231px; margin: 10px; float: left;" src="../img/man_besplodiya.jpg" alt="лечение бесплодия" /><img style="width: 350px; height: 231px; margin: 10px; float: left;" src="../img/ginekologija1.jpg" alt="лечение бесплодия в москве" /></p>

<div class="clr"></div>

<h2>Причины бесплодия</h2>

<h3>ведущими причинами бесплодия являются:</h3>

<ul class="spisok">
	<li>Первая причина бесплодия - трубно-перитонеальный фактор (нарушение проходимости маточных труб);</li>
	<li>Вторая причина бесплодия - эндокринные нарушения;</li>
	<li>Третья причина бесплодия - эндометриоз;</li>
	<li>Четвертая причина бесплодия - мужской фактор;</li>
	<li>Пятая причина бесплодия - анатомические нарушения (заращение полости матки, отсутствие матки);</li>
	<li>Шестая причина, которая может вызвать бесплодие - иммунологические нарушения.</li>
</ul>

<div class="clr"></div>

<p>В 15–20 % случаев отмечается бесплодие неясного происхождения.</p>

<p>Чем раньше пациенты, у которых есть бесплодие, обращаются к специалистам, тем проще врачам выявить причину и способы лечения бесплодия. Не теряйте драгоценное время, которое можно провести уже в ожидании будущего малыша - пройдите программу лечения бесплодия. За консультацией и если необходимо лечение  бесплодия у женщин и мужчин обращайтесь в нашу специализированную клинику по адресу: Москва, шоссе Энтузиавстов, д. 11А, корп. 3 или позвоните по телефону <span class="bold">+7 (495) 256-38-00</span>.</p>

		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
<li><a href="/vedenie-beremennosti-ceny/">Беременность</a>, 
	<a href="/lecheniye-bakterialnogo-vaginoza/">Вагиноз</a>, 
	<a href="/bartolinit/">Бартолинит</a>, 
	<a href="/salpingooforit-adneksit/">Аднексит</a>, 
	<a href="/endometrit-metroendometrit/">Эндометрит</a>, 
	<a href="/endocervicit/">Эндоцервицит</a>, 
	<a href="/endometrioz/">Эндометриоз</a>, 
	<a href="/eroziya-sheiki-matki/">Эрозия шейки матки</a>, 
	<a href="/infekcii-zhenskoi-polovoi-sistemy/">Инфекции женской половой системы</a>, 
	<a href="/proyavlenie-gormonalnyh-narushenii/">Гормональные нарушения</a>, 
	<a href="/diagnostika-besplodiya/">Бесплодие</a>, 
	<a href="/klimaks/">Климакс</a>, 
	<a href="/narushenie-menstrualnogo-cikla/">Нарушение менструального цикла</a>, 
	<a href="/kontracepciya/">Контрацепция</a>, 
	<a href="/medikomentoznyi-abort/">Медикаментозный аборт </a>
</li>
<li><a href="/diagnostika-bakterialnogo-vaginoza/">Диагностика бактериального вагиноза</a>, 
	<a href="/etiologiya-bakterialnogo-vaginoza/">Этиология бактериального вагиноза</a>, 
	<a href="/zarazhenie-bakterialnym-vaginozom/">Заражение бактериальным вагинозом</a>, 
	<a href="/klinika-bakterialnogo-vaginoza/">Клиника бактериального вагиноза</a>, 
	<a href="/bakterialnyi-vaginoz-oslozhneniya/">Бактериальный вагиноз - осложнения </a>
</li>
<li><a href="/prichiny-gormonalnyh-narushenii/">Причины гормональных нарушений</a>, 
	<a href="/lechenie-i-diagnostika-gormonalnyh-narushenii/">Лечение и диагностика гормональных нарушений </a>
</li>
<li>
	<a href="/lecheniye-zhenskogo-besplodiya/">Лечение женского бесплодия</a>
</li>
<li>
	<a href="/farmabort/">Фармаборт</a>, 
	<a href="/bezoperacionnyi-abort/">Безоперационный аборт</a>, 
	<a href="/abort-tabletkami/">Аборт таблеткам</a>
</li>

</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>