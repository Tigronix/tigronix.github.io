﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Лечение гонореи у женщин - цены, запись на прием. Медицинский центр на Авиамоторной</title>
<meta name="description" lang="ru" content="Диагностика и лечение гонореи у женщин в медклинике на Авиамоторной. Первичный прием венеролога  1000 рублей. Анализы методом ПЦР от 240 рублей. Виды гонореи. Запись на прием +7 (495) 256-38-00" />
<meta name="keywords" lang="ru" content="Лечение гонореи у женщин" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/lecheniye-gonorei/">Гонорея</a></li> <li>Лечение гонореи у женщин</li></ul>
		
		
		
		<div class="rside_txt">
		
			
	        		<h1>Лечение гонореи у женщин</h1>
					
					<p>Гонорея у женщин может протекать совершенно безсимптомно. Это может быть обусловлено сниженной функцией яичников и еще некоторым рядом причин. Гонорея у женщин может поражать несколько органов одновременно. При гонореи у женщин не редки случаи, когда заболевание протекает как смешанное с другими половыми болезнями. При первом обнаружении симптомов гонореи Вам необходимо сразу же обратиться к врачу и пройти своевременное лечение гонореи.</p>

<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>


<div class="doc_info">
			
						<table class="tbl_doc_info">
							<tbody><tr>
								<td width="469">
									<img src="../images/foto_3.png" width="165" height="186" alt="img">
									<div class="tbl_spec_fio">
										Диденко<br />
Елена<br />
Юрьевна
									</div>
									<div class="tbl_spec_dolj">Дерматовенеролог, уролог, андролог.<br>Врач 1 категории</div>
								</td>
								<td width="333" class="tbl_doc_info_right">
									<span class="bold">Записаться на прием можно:</span><br>
									
									На сайте:
									
									<div class="arrow_bot"></div>
									
									<span class="btn_zapis_wrap">
										<a href="/zayavka/" class="btn_zapis">Онлайн запись на прием</a>
									</span>
									<div class="tbl_doc_info_contact">
										По телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
									</div>
								</td>
							</tr>
						</tbody></table>
					
			</div>

<h2>Стоимость услуг лечения гонореи</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость услуг</td>
	</tr>
</thead>
	<tbody>
		<tr>
			<td colspan="4">Дерматовенерология</td>
		</tr>
		<tr>
			<td>Первичный приём венеролога с осмотром</td>
			<td class="price">1 000 р</td>
		</tr>
		<tr>
			<td>Повторный приём</td>
			<td class="price">800 р</td>
		</tr>
		<tr>
			<td>Исследование мазков на флору</td>
			<td class="price">450-00</td>
		</tr>
		<tr>
			<td>Исследование мазков на бак.посев</td>
			<td class="price">От 620-00</td>
		</tr>
		<tr>
			<td>Лечебное сопровождение при прохождении курса лечения</td>
			<td class="price">2 500</td>
		</tr>
		<tr class="tbl_price_thead">
			<td colspan="2">Анализы на Гонорею</td>
			</tr>
		<tr>
			<td>Гонорея (Neisseria gonorrheae)(качественный)</td>
			<td class="price">240-00</td>
		</tr>
		<tr>
			<td>Гонорея (Neisseria gonorrheae) (количественный)</td>
			<td class="price">440-00</td>
		</tr>
	</tbody>
</table>

<p>Гонорея подразделяется на несколько видов.</p>

<p><span class="bold">Уретрит</span></p>

<p>Симптомы при уретрите (гонорее): зуд, болезненные ощущения в начале мочеиспускания, часто позывы к мочеиспусканию, слизистые, не имеющие цвета выделения.</p>

<p><span class="bold">Парауретрит</span> достаточно часто идет в паре с уретритом гонококковой этиологии. Устья протоков воспалены и имеют слизистые, иногда вместе с гноем выделения. При нажатии образуется каплевидные выделения. Именно в выделениях во время анализа и обнаруживают гонококки.</p>

<p>Часто гонорея поражает преддверие влагалища. При гонореи такого типа процесс происходит в ямке и луковице, могут подвергаться мелкие железы возле клитора, бороздки. Замечаются выделения гноя и слизи, отек влагалища.</p>

<p><span class="bold">Бартолинит</span></p>

<p>При такой гонорее инфекция поражает большие железы в преддверии влагалища. Врач обнаруживает на устье выводного протока железы  пятно, имеющее темно-красный цвет и по форме напоминающую горошину.</p>

<p>Во время осмотра врач проводит пальпацию, в результате которой выдавливает каплевидную слизь. Если во время не обратится к врачу, со временем выводной проток может закрыться, и на месте пятна образуется киста.</p>

<p>У некоторых больных при гонореи болезнь охватывает и окружающие ткани. Железы воспаляются и отекают, чувствуется боль. Хуже всего себя пациент чувствует, если при гонореи у женщин инфекция смешана с гонококками и хламидиями.</p>

<p>Гонорея вызывает воспаление шейки и шеечного канала матки. Это встречается очень часто при гонококковых инфекциях. Из шеечного канала обнаруживаются выделения слизи и гноя. Врач, проводя осмотр, видит отечность, матка поражена эрозией. В основном заболевание протекает безсимптомно.</p>

<p><span class="bold">Эндометрит</span></p>

<p>Поражает слизистую оболочку матки. Это заболевание бывает острого и хронического типа. У больных гонореей наблюдается высокая температура тела, сильная боль внизу живота, нарушение менструации, выделение слизи или гноя из влагалища. При этом матка увеличивается, имеет тестоватую консистенцию и также вызывает болезненные ощущения. Это симптомы острого эндометрита. При хроническом - симптомы не так ярко выражены. Боль внизу живота ощущается во время полового акта или при разных физических нагрузках, менструация нарушена, а матка увеличивается и по консистенции становится немного плотнее.</p>

<p>Также распространен и<span class="bold"> сальпингит</span>. Он бывает разного вида в зависимости от пораженного участка. Симптомы те же – выделения слизи и гноя, отек, спайки, боль внизу живота как при менструации, при нагрузках боль может усиливаться. Если женщина вовремя не обратится к врачу, и будет злоупотреблять алкоголем и частыми разносторонними половыми актами, заболевание гонореей обостряется.</p>

<p>Существует и такая разновидность гонореи как <span class="bold">гонококковый сальпингит</span>. У больных повышается температура, беспокоят болезненные ощущения внизу живота, нарушенный менструальный цикл, временем образуются спайки.</p>

<p>После перенесенной гонореи пациентка может страдать бесплодием, перитонитом, внематочной беременностью.</p>

<p><span class="bold">Гонорейный пальвеоперитонит</span> - еще одна разновидность гонореи. Больных гонореей беспокоит боль резкого характера, метеоризм, неприятный запах изо рта, повышенная температура. Вследствие перенесенной гонореи женщины могут страдать бесплодием.</p>

<p>Очень важно при малейших симптомах обратиться к врачу, ведь от оказания качественной помощи зависит и Ваша будущая жизнь.</p>

<p>Наша клиника имеет огромный опыт излечения гонореи у женщин. Обращайтесь к нам, и Вы получите своевременное качественное медицинское обслуживание!</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li><a href="/priem-dermatologa/">Консультация венеролога</a>
		</li>
	<li><a href="/diagnostika-kandidoza/">Кандидоз</a>, 
		<a href="/lecheniye-kandidoza-v-moskve/">Лечение кандидоза</a>, 
		<a href="/epidemiologiya-kandidoza/">Эпидемиология кандидоза</a>, 
		<a href="/klinika-kandidoza/">Клиника кандидоза</a>
		</li>
	<li><a href="/lechenie-mikoplazmoza/">Микоплазмоз</a>
		</li>
	<li><a href="/lecheniye-khlamidioza-v-moskve/">Хламидиоз</a>, 
		<a href="/diagnostika-khlamidioza/">Диагностика хламидиоза</a>, 
		<a href="/lecheniye-khlamidioza-u-zhenshchin/">Лечение хламидиоза у женщин</a>, 
		<a href="/lecheniye-khlamidioza-u-muzhchin/">Лечение хламидиоза у мужчин</a>
		</li>
	<li><a href="/diagnostika-gerpesa/">Генитальный герпес</a>, 
		<a href="/lecheniye-genitalnogo-gerpesa/">Лечение генитального герпеса</a>, 
		<a href="/etiologiya-gerpesa/">Этиология герпеса</a>
		</li>
	<li><a href="/lecheniye-ureaplazmoza-u-zhenshchin/">Уреаплазмоз</a>
		</li>
	<li><a href="/lecheniye-papillomavirusa/">Папилломавирус</a>, 
		<a href="/diagnostika-vpch/">Диагностика ВПЧ</a>
		</li>
	<li><a href="/lechenie-trihomoniaza/">Трихомониаз</a>, 
		<a href="/diagnostika-trikhomoniaza/">Диагностика трихомониаза</a>
		</li>
	<li><a href="/lecheniye-gonorei/">Гонорея</a>, 
		<a href="/diagnostika-gonorei/">Диагностика гонореи</a>, 
		<a href="/lecheniye-gonorei-u-muzhchin/">Лечение гонореи у мужчин</a>, 
		<a href="/gonoreya-u-detei/">Гонорея у детей</a>, 
		<a href="/etiologiya-gonorei/">Этиология гонореи</a>
		</li>
	<li><a href="/sifilis/">Сифилис</a>, 
		<a href="/etiologiya-sifilisa/">Этиология сифилиса</a>, 
		<a href="/puti-zarazheniya/">Пути заражения</a>, 
		<a href="/pervichnyi-period-sifilisa/">Первичный период сифилиса</a>, 
		<a href="/vtorichnyi-period-sifilisa/">Вторичный период сифилиса</a>, 
		<a href="/tretichnyi-period-sifilisa/">Третичный период сифилиса</a>, 
		<a href="/skrytyi-sifilis/">Скрытый сифилис</a>, 
		<a href="/neirosifilis/">Нейросифилис</a>, 
		<a href="/viscerosifilis/">Висцеросифилис</a>, 
		<a href="/vrozhdennyi-sifilis/">Врожденный сифилис</a>, 
		<a href="/diagnostika-sifilisa/">Диагностика сифилиса</a>
		</li>
	<li>
		<a href="/vich/">ВИЧ</a>
	</li>	
</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>