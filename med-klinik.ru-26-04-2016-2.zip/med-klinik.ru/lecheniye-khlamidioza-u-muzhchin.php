﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Хламидиоз у мужчин: симптомы, лечение, цены, запись на прием - Медицинский центр на Авиамоторной</title>
<meta name="description" lang="ru" content="Лечение хламидиоза у мужчин от 2500 рублей в медклинике на Авиамоторной - лечебное сопровождение при прохождении курса лечения. Симптомы, схемы лечения. Запись на прием +7 (495) 256-38-00" />
<meta name="keywords" lang="ru" content="Лечение хламидиоза у мужчин" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/lecheniye-khlamidioza-v-moskve/">Хламидиоз</a></li> <li>Лечение хламидиоза у мужчин</li></ul>
		
		
		
		<div class="rside_txt">
		
			
	        		<h1>Лечение хламидиоза у мужчин</h1>
					
					<p><span class="bold">Хламидиоз</span> – это инфекционное заболевание, передающееся исключительно половым путем. Хламидиоз у мужчин может быть приобретен только во время полового контакта без презерватива с уже инфицированным больным. Заразиться хламидиозом бытовым путем невозможно.</p>

<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>

<h2>Прием ведут:</h2>


<table class="tbl_spec tbl_spec_2">
			<tbody><tr>
				<td width="419">
						<img src="../images/foto_2.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Алексеев<br>
							Александр<br>
							Львович
						</div>
						<div class="tbl_spec_dolj">Уролог, андролог, сексолог, <br>врач высшей категории</div>
						<a href="/alekseev-aleksandr-lvovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
				<td width="417">
						<img src="../images/foto_3.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Диденко<br>
							Елена<br>
							Юрьевна
						</div>
						<div class="tbl_spec_dolj">Дерматовенеролог, уролог, андролог.<br>Врач 1 категории</div>
						<a href="/didenko-elena-yurevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
			<tr>
			
			<td>
						<img src="../images/foto_5.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Хмелевский<br>
							Игорь<br>
							Станиславович
						</div>
						<div class="tbl_spec_dolj">Уролог-андролог. <br>Врач 1 категории</div>
						<a href="/hmelevskii-igor-stanislavovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					<td>
						<img src="../images/foto_8.png" width="165" height="186" alt="img">
					<div class="tbl_spec_fio">
						Шиленина<br>
						Елена<br>
						Николаевна
					</div>
					<div class="tbl_spec_dolj">Акушер-гинеколог, <br>врач высшей категории</div>
					<a href="/shilenina-elena-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
			<tr>
				<td>
						<img src="../images/foto_4.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Букинская<br>
							Елена<br>
							Владимировна
						</div>
						<div class="tbl_spec_dolj">Акушер-гинеколог, врач <br>высшей категории</div>
						<a href="/bukinskaya-elena-vladimirovna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					<td>
						<img src="../images/foto_7.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Петрашко<br>
							Татьяна<br>
							Николаевна
						</div>
						<div class="tbl_spec_dolj">Врач акушер гинеколог, <br>врач высшей категории</div>
						<a href="/petrashko-tatyana-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
				
			</tr>
		</tbody></table>

<h2>Стоимость услуг:</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>
	<tbody>
		<tr>
			<td colspan="4">Урология</td>
		</tr>
		<tr>
			<td>Прием врача (уролог)  КМН</td>
			<td class="price">1 500</td>
		</tr>
		<tr>
			<td>Консультация врача  первичная с осмотром</td>
			<td class="price">1 000</td>
		</tr>
		<tr>
			<td>Прием врача уролога (уролога-андролога) повторный с осмотром</td>
			<td class="price">800</td>
		</tr>
		<tr class="tbl_price_thead">
			<td colspan="4">Диагностика в урологии</td>
		</tr>
		<tr>
			<td>мазок из уретры</td>
			<td class="price">450</td>
		</tr>
		<tr>
			<td>Мазок отпечаток</td>
			<td class="price">450</td>
		</tr>
		<tr>
			<td>Пальцевое ректальное исследование</td>
			<td class="price">800</td>
		</tr>
		<tr>
			<td>ПЦР-анализ</td>
			<td class="price">240</td>
		</tr>
		<tr>
			<td>Взятие бак.посева</td>
			<td class="price">от 850</td>
		</tr>
		<tr>
			<td>Анализы на инфекции ХЛАМИДИОЗ</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>Хламидиоз (Chlamidia trachomatis)(качественный)</td>
			<td class="price">240</td>
		</tr>
		<tr>
			<td>Хламидиоз (Chlamidia trachomatis) (количественный)</td>
			<td class="price">440 </td>
		</tr>
		<tr class="tbl_price_thead">
			<td colspan="4">Программы терапии мужчин в урологии (хламидиоза, трихомониаза и др.)</td>
		</tr>
		<tr>
			<td>Лечебное сопровождение при прохождении курса лечения хламидиоза</td>
			<td class="price">2 500</td>
		</tr>
	</tbody>
</table>

<p>При хламидиозе у пациентов  бывают выделения слизистого характера и белого цвета из уретры, зуд и даже боль в мочеиспускательном канале, частые позывы в туалет. На самых ранних стадиях хламидиоза у мужчин выделения достаточно слабые.</p>

<p><img class="img_center" style="width: 500px; height: 375px; margin: 10px;" src="../img/nsp_khlamidia_clip_image006.jpg" alt="лечение хламидиоза у мужчин" /></p>

<div class="clr"></div>

<p><span class="bold">Хламидийный эпидидимит</span> происходит в следствии заражения хламидиями из задней уретры. Вначале поражается уретра, потом начинается простатит, далее – везикулит. Именно таким образом происходит развитие хламидийного эпидидимита. Врач легко может обнаружить воспаленный проток при пальпации.</p>

<p>Хламидиоз может быть острым, подострым и хроническим. При острой форме хламидиоза прослеживается увеличение температуры тела до 39 С, болезненные ощущения в придатке яичка, отдающие в поясничную и крестовую зоны. Внешне наблюдается отечность и воспаление кожи со стороны больного придатка, нащупывается плотный бугор.</p>

<p>Во время протекания подострого эпидидимита пациент чувствует умеренную боль, симптомы хламидиоза выражены не так остро. Температура тела не повышается, не так сильно увеличивается придаток.</p>

<p>При <span class="bold">хламидийном орхоэпидидимите</span> воспаляется оболочка на яичке. При этом мошонка воспаленная, а на ощупь - горячая, во время  пальпации у больного резкие боли. Если одновременно наблюдается простатит, а также везикулит с деферентитом у больного происходят изменения в половой функции и сперматограмма.</p>

<p><span class="bold">Хламидийный простатит</span> явления достаточно распространенное при заболевании хламидийным уретритом. В таком случае пациент жалуется на выделения и зуд из канала мочеиспускания и прямой кишки, прослеживаются болезненные ощущения в паховой зоне, мошонке, крестце.</p>

<p><span class="bold">Хламидийный парауретрит </span>и везикулит протекают без осложнений, симптомы не ярко  выражены.</p>

<p><span class="bold">Хламидийный проктит</span> появляется в следствии гениторектального полового акта. Симптомы такого типа хламидиоза: слабые болезненные ощущения в прямой кишке, слизистые выделения, иногда бывают кровотечения.</p>

<p>Терапия хламидиоза  и профилактика проводится в течении трех недель, при условии, что у больного нет осложнений. Профилактика у мужчин и лечение хламидиоза обязательна для обоих партнеров, даже если второй не инфицирован хламидиозом. Во время лечения хламидиоза запрещаются половые контакты.</p>

<p>Как правило, врач назначает антибиотики и иммуномодулирующие препараты. Также пациент, страдающий хламидиозом, проходит физиотерапевтические процедуры. Для каждого пациента лечение хламидиоза подбирается индивидуально. Не стоит заниматься самолечением хламидиоза у мужчин, дабы хламидиоз не прогрессировал в хроническую форму.</p>

<p>Мы лечим хламидиоз. Обращайтесь за диагностикой и терапией хламидиоза у мужчин в нашу клинику. Связаться с нашими специалистами можно по телефону +7 (495) 256-38-00</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li><a href="/priem-dermatologa/">Консультация венеролога</a>
		</li>
	<li><a href="/diagnostika-kandidoza/">Кандидоз</a>, 
		<a href="/lecheniye-kandidoza-v-moskve/">Лечение кандидоза</a>, 
		<a href="/epidemiologiya-kandidoza/">Эпидемиология кандидоза</a>, 
		<a href="/klinika-kandidoza/">Клиника кандидоза</a>
		</li>
	<li><a href="/lechenie-mikoplazmoza/">Микоплазмоз</a>
		</li>
	<li><a href="/lecheniye-khlamidioza-v-moskve/">Хламидиоз</a>, 
		<a href="/diagnostika-khlamidioza/">Диагностика хламидиоза</a>, 
		<a href="/lecheniye-khlamidioza-u-zhenshchin/">Лечение хламидиоза у женщин</a>
		</li>
	<li><a href="/diagnostika-gerpesa/">Генитальный герпес</a>, 
		<a href="/lecheniye-genitalnogo-gerpesa/">Лечение генитального герпеса</a>, 
		<a href="/etiologiya-gerpesa/">Этиология герпеса</a>
		</li>
	<li><a href="/lecheniye-ureaplazmoza-u-zhenshchin/">Уреаплазмоз</a>
		</li>
	<li><a href="/lecheniye-papillomavirusa/">Папилломавирус</a>, 
		<a href="/diagnostika-vpch/">Диагностика ВПЧ</a>
		</li>
	<li><a href="/lechenie-trihomoniaza/">Трихомониаз</a>, 
		<a href="/diagnostika-trikhomoniaza/">Диагностика трихомониаза</a>
		</li>
	<li><a href="/lecheniye-gonorei/">Гонорея</a>, 
		<a href="/diagnostika-gonorei/">Диагностика гонореи</a>, 
		<a href="/lecheniye-gonorei-u-muzhchin/">Лечение гонореи у мужчин</a>, 
		<a href="/lecheniye-gonorei-u-zhenshchin/">Лечение гонореи у женщин</a>, 
		<a href="/gonoreya-u-detei/">Гонорея у детей</a>, 
		<a href="/etiologiya-gonorei/">Этиология гонореи</a>
		</li>
	<li><a href="/sifilis/">Сифилис</a>, 
		<a href="/etiologiya-sifilisa/">Этиология сифилиса</a>, 
		<a href="/puti-zarazheniya/">Пути заражения</a>, 
		<a href="/pervichnyi-period-sifilisa/">Первичный период сифилиса</a>, 
		<a href="/vtorichnyi-period-sifilisa/">Вторичный период сифилиса</a>, 
		<a href="/tretichnyi-period-sifilisa/">Третичный период сифилиса</a>, 
		<a href="/skrytyi-sifilis/">Скрытый сифилис</a>, 
		<a href="/neirosifilis/">Нейросифилис</a>, 
		<a href="/viscerosifilis/">Висцеросифилис</a>, 
		<a href="/vrozhdennyi-sifilis/">Врожденный сифилис</a>, 
		<a href="/diagnostika-sifilisa/">Диагностика сифилиса</a>
		</li>
	<li>
		<a href="/vich/">ВИЧ</a>
	</li>	
</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>