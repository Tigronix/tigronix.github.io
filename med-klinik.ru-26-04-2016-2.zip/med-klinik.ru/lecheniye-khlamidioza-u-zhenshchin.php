﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Лечение хламидиоза у женщин - Цены, запись на прием | Виды хламидиоза</title>
<meta name="description" lang="ru" content="Диагностика и лечение хламидиоза у женщин в медклинике на Авиамоторной. Лечебное сопровождение при прохождении курса лечения - 2500 рублей. Запись на прием +7 (495) 256-38-00" />
<meta name="keywords" lang="ru" content="Лечение хламидиоза у женщин" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/lecheniye-khlamidioza-v-moskve/">Хламидиоз</a></li> <li>Лечение хламидиоза у женщин</li></ul>
		
		
		
		<div class="rside_txt">
		
			
	        		<h1>Лечение хламидиоза у женщин</h1>
					
					<p>Хламидиоз у женщин проявляется в разных формах.</p>

<p>Хламидиоз очень распространен, и у многих женщин может проходить без каких-либо симптомов. Очень редко при хламидиозе у женщин есть жалобы на слабые выделения из влагалища, может быть небольшой зуд, нарушение мочеиспускания, кровотечения не связанные с менструацией.</p>


<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>

<h2>Прием ведут:</h2>


<table class="tbl_spec tbl_spec_2">
			<tbody><tr>
				<td width="419">
						<img src="../images/foto_2.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Алексеев<br>
							Александр<br>
							Львович
						</div>
						<div class="tbl_spec_dolj">Уролог, андролог, сексолог, <br>врач высшей категории</div>
						<a href="/alekseev-aleksandr-lvovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
				<td width="417">
						<img src="../images/foto_3.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Диденко<br>
							Елена<br>
							Юрьевна
						</div>
						<div class="tbl_spec_dolj">Дерматовенеролог, уролог, андролог.<br>Врач 1 категории</div>
						<a href="/didenko-elena-yurevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
			<tr>
			
			<td>
						<img src="../images/foto_5.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Хмелевский<br>
							Игорь<br>
							Станиславович
						</div>
						<div class="tbl_spec_dolj">Уролог-андролог. <br>Врач 1 категории</div>
						<a href="/hmelevskii-igor-stanislavovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					<td>
						<img src="../images/foto_8.png" width="165" height="186" alt="img">
					<div class="tbl_spec_fio">
						Шиленина<br>
						Елена<br>
						Николаевна
					</div>
					<div class="tbl_spec_dolj">Акушер-гинеколог, <br>врач высшей категории</div>
					<a href="/shilenina-elena-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
			<tr>
				<td>
						<img src="../images/foto_4.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Букинская<br>
							Елена<br>
							Владимировна
						</div>
						<div class="tbl_spec_dolj">Акушер-гинеколог, врач <br>высшей категории</div>
						<a href="/bukinskaya-elena-vladimirovna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					<td>
						<img src="../images/foto_7.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Петрашко<br>
							Татьяна<br>
							Николаевна
						</div>
						<div class="tbl_spec_dolj">Врач акушер гинеколог, <br>врач высшей категории</div>
						<a href="/petrashko-tatyana-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
				
			</tr>
		</tbody></table>

<h2>Стоимость услуг:</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>
	<tbody>
		<tr>
			<td colspan="2">Гинекология</td>
		</tr>
		<tr>
			<td>Прием гинеколога (первичная консультация)</td>
			<td class="price"><span class="red_txt">1 000</span> </td>
		</tr>
		<tr>
			<td>Прием (повторная консультация)</td>
			<td class="price">800</td>
		</tr>
		<tr>
			<td>Гинеколог-эндокринолог (прием и первичная / повторная конс)</td>
			<td class="price">1 000 / 800</td>
		</tr>
		<tr>
			<td>Исследование мазков на флору</td>
			<td class="price">450</td>
		</tr>
		<tr>
			<td>Исследование мазков на бак.посев</td>
			<td class="price">От 620</td>
		</tr>
		<tr>
			<td>Исследование мазков  ПЦР-анализ (1 инф)</td>
			<td class="price">240</td>
		</tr>
		<tr class="tbl_price_thead">
			<td colspan="2">Анализы на инфекции ХЛАМИДИОЗ</td>
			</tr>
		<tr>
			<td>Хламидиоз (Chlamidia trachomatis)(качественный)</td>
			<td class="price">240</td>
		</tr>
		<tr>
			<td>Хламидиоз (Chlamidia trachomatis) (количественный)</td>
			<td class="price">440</td>
		</tr>
		<tr>
			<td>Лечение хламидиоза (лечебное сопровождение)</td>
			<td class="price">от 2 500</td>
		</tr>
		<tr>
			<td valign="top">&nbsp;</td>
			<td>
			
			</td>
		</tr>
	</tbody>
</table>

<p>В наше время медицина очень развита и всестороння. Опытный врач безошибочно установит -  каким именно видом хламидиоза страдает пациентка, и назначит соответствующую схему лечения хламидиоза у женщин.</p>

<p><img class="img_center" style="width: 500px; height: 350px; margin: 10px;" src="../img/cikl-razvitiy-hlamidii.png" alt="лечение хламидиоза у женщин" /></p>

<div class="clr"></div>

<p>Бывает <span class="bold">хламидийный уретрит</span>, который сопровождается у женщин жалобами на зуд в мочеиспускательном канале, боль и частые позывы в туалет. У пациентки при хламидиозе может обнаружиться небольшое раздражение на внешней части канала, а после некоего массажа слабые выделения, не имеющие цвет.</p>

<p><span class="bold">Хламидийный бартолинит</span> не отличается жалобами и симптомами. Такой вид хламидиоза у женщин возможно обнаружить только при пальпации. Если при хламидиозе происходит закупорка выводного протока железы, на этом месте образуется киста. Это может быть очень опасно, и обращаться следует только к опытнейшему врачу для лечения и диагностики хламидиоза у женщин.</p>

<p> <span class="bold">Хламидийный сальпингит</span> является самым распространенным. Женщины жалуются на боль внизу живота, нарушенный менструальный цикл, боль при мочеиспускании, выделения.  Боль может быть слабовыраженной, но имеет свойство усиливаться при гинекологическом осмотре, во время менструации и пр.  Температура тела может повышаться до 39С. У многих женщин, страдающих хламидиозом, поражаются и маточные трубы, яичники. Следствием сальпингита может быть непроходимость и трубная беременность. В этом случае неоходимо незамедлительное лечение.</p>

<p><img class="img_center" style="width: 400px; height: 296px; margin: 10px;" src="../img/hlamidioz.jpg" alt="лечение хламидиоза у женщин" /></p>

<div class="clr"></div>

<p>При хламидийном сальпингофорите поражаются урогенитальный тракт, маточные трубы, яичники. Женщины жалуются на ноющие болезненные ощущения внизу живота и зоне крестца. Наблюдаются и кровотечения не связанные с менструальным периодом.</p>

<p>Хламидийный пельвиоперитонит является осложнением двух вышеперечисленных видов хламидиоза. Внизу живота появляется резкая боль, повышается температура тела, учащается пульс, может быть метеоризм, задержка стула. В таком случае необходимо срочное лечение.</p>

<p>Во время лечения хламидиоза очень важен индивидуальный подход. Врач, как правило, для лечения назначает комплексно антибиотики с препаратами, поддерживающими иммунитет, и диету. Также лечение должен пройти и партнер. Не стоит лечить хламидиоз самостоятельно, ведь последствия могут быть самыми серьезными. При хламидиозе у женщин лечение должен назначить специалист, и хороший результат не заставит себя долго ждать.</p>

<p>Его результаты готовы уже после двух часов, а результат покажет наличие в организме антител инфекции.</p>

<p>Бывают случаи, когда при обследовании врач обнаруживает и другие заболевания. Тогда назначаются дополнительные обследования и анализы.</p>

<p>Помните, что своевременная диагностика позволяет в кратчайшие сроки и без последствий убрать инфекцию из организма, и жить полноценной жизнью.</p>



	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li><a href="/priem-dermatologa/">Консультация венеролога</a>
		</li>
	<li><a href="/diagnostika-kandidoza/">Кандидоз</a>, 
		<a href="/lecheniye-kandidoza-v-moskve/">Лечение кандидоза</a>, 
		<a href="/epidemiologiya-kandidoza/">Эпидемиология кандидоза</a>, 
		<a href="/klinika-kandidoza/">Клиника кандидоза</a>
		</li>
	<li><a href="/lechenie-mikoplazmoza/">Микоплазмоз</a>
		</li>
	<li><a href="/lecheniye-khlamidioza-v-moskve/">Хламидиоз</a>, 
		<a href="/diagnostika-khlamidioza/">Диагностика хламидиоза</a>, 
		<a href="/lecheniye-khlamidioza-u-muzhchin/">Лечение хламидиоза у мужчин</a>
		</li>
	<li><a href="/diagnostika-gerpesa/">Генитальный герпес</a>, 
		<a href="/lecheniye-genitalnogo-gerpesa/">Лечение генитального герпеса</a>, 
		<a href="/etiologiya-gerpesa/">Этиология герпеса</a>
		</li>
	<li><a href="/lecheniye-ureaplazmoza-u-zhenshchin/">Уреаплазмоз</a>
		</li>
	<li><a href="/lecheniye-papillomavirusa/">Папилломавирус</a>, 
		<a href="/diagnostika-vpch/">Диагностика ВПЧ</a>
		</li>
	<li><a href="/lechenie-trihomoniaza/">Трихомониаз</a>, 
		<a href="/diagnostika-trikhomoniaza/">Диагностика трихомониаза</a>
		</li>
	<li><a href="/lecheniye-gonorei/">Гонорея</a>, 
		<a href="/diagnostika-gonorei/">Диагностика гонореи</a>, 
		<a href="/lecheniye-gonorei-u-muzhchin/">Лечение гонореи у мужчин</a>, 
		<a href="/lecheniye-gonorei-u-zhenshchin/">Лечение гонореи у женщин</a>, 
		<a href="/gonoreya-u-detei/">Гонорея у детей</a>, 
		<a href="/etiologiya-gonorei/">Этиология гонореи</a>
		</li>
	<li><a href="/sifilis/">Сифилис</a>, 
		<a href="/etiologiya-sifilisa/">Этиология сифилиса</a>, 
		<a href="/puti-zarazheniya/">Пути заражения</a>, 
		<a href="/pervichnyi-period-sifilisa/">Первичный период сифилиса</a>, 
		<a href="/vtorichnyi-period-sifilisa/">Вторичный период сифилиса</a>, 
		<a href="/tretichnyi-period-sifilisa/">Третичный период сифилиса</a>, 
		<a href="/skrytyi-sifilis/">Скрытый сифилис</a>, 
		<a href="/neirosifilis/">Нейросифилис</a>, 
		<a href="/viscerosifilis/">Висцеросифилис</a>, 
		<a href="/vrozhdennyi-sifilis/">Врожденный сифилис</a>, 
		<a href="/diagnostika-sifilisa/">Диагностика сифилиса</a>
		</li>
	<li>
		<a href="/vich/">ВИЧ</a>
	</li>	
</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>