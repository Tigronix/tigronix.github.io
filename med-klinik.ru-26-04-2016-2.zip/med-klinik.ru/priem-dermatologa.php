﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Прием дерматолога в Москве - запись, цены, услуги</title>
<meta name="description" lang="ru" content="Прием дерматолога в медклинике на Авиамоторной. Консультация, анализы, лечение. Прием дерматолога - 1500 руб. Удаление бородавок, новообразований и кондилом Запись на прием к дерматовенерологу. Контакты" />
<meta name="keywords" lang="ru" content="Прием дерматолога" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li>Консультация венеролога</li></ul>
		
		
		
		<div class="rside_txt">
		
<h1>Прием дерматолога</h1>

<p>Главным показателем состояния здоровья нашего организма является кожа, а так же ее реакция на факторы среды, что нас окружает. И поэтому заболевания кожи могут серьезно ослабить наш организм в целом, ведь кожа – это защитный орган нашего организма. И поэтому если Вы живете в условиях агрессивной среды мегаполиса, важно проводить диагностирование дерматологических проблем и назначать верное лечение на самых ранних стадиях заболевания. Новообразования на коже могут говорить о возможности онкологических заболеваний, которые имеют большой процент летального исхода. И чтобы избежать серьёзных последствий , нужно следить за состоянием кожи и регулярно обращаться к услугам специалиста для профилактики .</p>

<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>

<h2>Прием ведут:</h2>

<table class="tbl_spec tbl_spec_2">
			<tbody><tr>
				<td width="419">
						<img src="../images/foto_3.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Диденко<br>
							Елена<br>
							Юрьевна
						</div>
						<div class="tbl_spec_dolj">Дерматовенеролог, уролог, андролог.<br>Врач 1 категории</div>
						<a href="/didenko-elena-yurevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
		</tbody></table>
		
<h2>Дерматолог. Стоимость услуг</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>

	<tbody>
		<tr>
			<td colspan="4">Дерматовенерология</td>
		</tr>
		<tr>
			<td>Прием дерматолога</td>
			<td class="price">1 500 </td>
		</tr>
		<tr>
			<td>Прием дерматолога с назначением лечения</td>
			<td class="price">3000 </td>
		</tr>
		<tr>
			<td>Мазок из уретры</td>
			<td class="price">450 </td>
		</tr>
		<tr>
			<td>Анализ крови на сифилис</td>
			<td class="price">400</td>
		</tr>
		<tr>
			<td>ВИЧ-анализ</td>
			<td class="price">400</td>
		</tr>
		<tr>
			<td>Анализ на гепатит В-С</td>
			<td class="price">400 </td>
		</tr>
	</tbody>
</table>


<p><img style="width: 350px; height: 250px; margin: 10px; float: left;" src="../img/lazernoe-udalenie-borodavok.jpg" alt="прием дераматолога" /><img style="width: 350px; height: 250px; margin: 10px; float: left;" src="../img/lazernoe-udalenie-rodinok.jpg" alt="прием дерматолога" /></p>

<div class="clr"></div>

<p><span class="bold">Услуги, которые  мы предлагаем:</span></p>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>

	<tbody>
		<tr>
			<td>удаление остроконечных кондилом (независимо от количества)</td>
			<td class="price">5000 </td>
		</tr>
		<tr>
			<td>бородавок  (1 элемент на коже) с обезболиванием</td>
			<td class="price">2000 </td>
		</tr>
		<tr>
			<td>Обезболивание</td>
			<td class="price">800 </td>
		</tr>
		<tr class="tbl_price_thead">
			<td colspan="2">Удаление новообразований</td>
			</tr>
		<tr>
			<td>Удаление новообразования более 1см в диаметре</td>
			<td class="price">2000 </td>
		</tr>
		<tr>
			<td>Удаление новообразования до 1см в диаметре</td>
			<td class="price">1500 </td>
		</tr>
		<tr>
			<td>Удаление новообразования до 0.5см в диаметре</td>
			<td class="price">800 </td>
		</tr>
		<tr>
			<td>Удаление новообразования до 0.3см в диаметре</td>
			<td class="price">600 </td>
		</tr>
		<tr>
			<td>Удаление контагиозного моллюска (1 элемент)</td>
			<td class="price">600 </td>
		</tr>
		<tr class="tbl_price_thead">
			<td colspan="2">Лазеродеструкция</td>
			</tr>
		<tr>
			<td>Лазеродеструкция кондилом, папиллом, расположенных на половых органах ( независимо от количества)</td>
			<td class="price">7000 </td>
		</tr>
		<tr>
			<td>Лазеродеструкция 1 элемента, расположенного на коже (с обезболиванием)</td>
			<td class="price">800 </td>
		</tr>
		<tr>
			<td>Радиодеструкция подошвенной бородавки</td>
			<td class="price">3000 </td>
		</tr>
	</tbody>
</table>

<ul class="list">
	<li>Все необходимые анализы, которые понадобятся - сдаются у дерматолога ;</li>
	<li>Диагностика только у профильных специалистов - консультацию проводит ведет непосредственно дерматолог;</li>
	<li>Услуги косметологического характера – чистка лица, удаление бородавок, кондилом, папиллом, контагиозного моллюска;</li>
	<li>Устранение и лечение лишая, псориаза, экземы;</li>
	<li>Удаление кожных клещей, а так же лечение паразитических заболеваний кожи;</li>
	<li>Лечение грибковых заболеваний кожи - проводит дерматолог;</li>
	<li>Удаление родинок - проводит врач.</li>
</ul>

<p>Вы должны понимать, что успех от лечения дерматологических заболеваний во многом зависит от того как пациент настроен психологически и от доверия пациента к врачу, а так же готовности выполнять все предписания которые необходимы. Профессионализм наших врачей, современное оборудование – это то, что делает  процедуры максимально комфортными и безболезненными для пациентов. Закончив курс лечения вы обязательно получаете открытые рекомендации по профилактике заболеваний кожи.</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li><a href="/priem-dermatologa/">Консультация венеролога</a>
		</li>
	<li><a href="/diagnostika-kandidoza/">Кандидоз</a>, 
		<a href="/lecheniye-kandidoza-v-moskve/">Лечение кандидоза</a>, 
		<a href="/epidemiologiya-kandidoza/">Эпидемиология кандидоза</a>, 
		<a href="/klinika-kandidoza/">Клиника кандидоза</a>
		</li>
	<li><a href="/lechenie-mikoplazmoza/">Микоплазмоз</a>
		</li>
	<li><a href="/lecheniye-khlamidioza-v-moskve/">Хламидиоз</a>, 
		<a href="/diagnostika-khlamidioza/">Диагностика хламидиоза</a>, 
		<a href="/lecheniye-khlamidioza-u-zhenshchin/">Лечение хламидиоза у женщин</a>, 
		<a href="/lecheniye-khlamidioza-u-muzhchin/">Лечение хламидиоза у мужчин</a>
		</li>
	<li><a href="/diagnostika-gerpesa/">Генитальный герпес</a>, 
		<a href="/lecheniye-genitalnogo-gerpesa/">Лечение генитального герпеса</a>, 
		<a href="/etiologiya-gerpesa/">Этиология герпеса</a>
		</li>
	<li><a href="/lecheniye-ureaplazmoza-u-zhenshchin/">Уреаплазмоз</a>
		</li>
	<li><a href="/lecheniye-papillomavirusa/">Папилломавирус</a>, 
		<a href="/diagnostika-vpch/">Диагностика ВПЧ</a>
		</li>
	<li><a href="/lechenie-trihomoniaza/">Трихомониаз</a>, 
		<a href="/diagnostika-trikhomoniaza/">Диагностика трихомониаза</a>
		</li>
	<li><a href="/lecheniye-gonorei/">Гонорея</a>, 
		<a href="/diagnostika-gonorei/">Диагностика гонореи</a>, 
		<a href="/lecheniye-gonorei-u-muzhchin/">Лечение гонореи у мужчин</a>, 
		<a href="/lecheniye-gonorei-u-zhenshchin/">Лечение гонореи у женщин</a>, 
		<a href="/gonoreya-u-detei/">Гонорея у детей</a>, 
		<a href="/etiologiya-gonorei/">Этиология гонореи</a>
		</li>
	<li><a href="/sifilis/">Сифилис</a>, 
		<a href="/etiologiya-sifilisa/">Этиология сифилиса</a>, 
		<a href="/puti-zarazheniya/">Пути заражения</a>, 
		<a href="/pervichnyi-period-sifilisa/">Первичный период сифилиса</a>, 
		<a href="/vtorichnyi-period-sifilisa/">Вторичный период сифилиса</a>, 
		<a href="/tretichnyi-period-sifilisa/">Третичный период сифилиса</a>, 
		<a href="/skrytyi-sifilis/">Скрытый сифилис</a>, 
		<a href="/neirosifilis/">Нейросифилис</a>, 
		<a href="/viscerosifilis/">Висцеросифилис</a>, 
		<a href="/vrozhdennyi-sifilis/">Врожденный сифилис</a>, 
		<a href="/diagnostika-sifilisa/">Диагностика сифилиса</a>
		</li>
	<li>
		<a href="/vich/">ВИЧ</a>
	</li>	
</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>