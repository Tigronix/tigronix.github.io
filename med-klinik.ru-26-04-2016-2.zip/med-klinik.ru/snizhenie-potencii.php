﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Снижение потенции</title>
<meta name="description" lang="ru" content="Снижение потенции" />
<meta name="keywords" lang="ru" content="Снижение потенции" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/konsultatsiya-androloga/">Консультация андролога</a></li> <li>Снижение потенции</li></ul>
		
		
		
		<div class="rside_txt">
		
			
	        		<h1>Снижение потенции</h1>
					
					<p>Обычно потенция зависит от возраста мужчины, в двадцать лет у молодых людей чуть ли не круглосуточная эрекция, к тридцати годам мужчина становится немного спокойней и размереннее в сексуальной жизни. К сорока годам мужчина все еще активен и плюс к этому приобретается огромный опыт, а вот после пятидесяти организм мужчины стареет, клетки все медленнее обновляются, половые гормоны вырабатываются медленнее, при этом сексуальное влечение все еще есть, но вот с потенцией могут быть проблемы.</p>

<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>

<h2>Прием ведут:</h2>


<table class="tbl_spec tbl_spec_2">
			<tbody><tr>
				<td width="419">
						<img src="../images/foto_2.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Алексеев<br>
							Александр<br>
							Львович
						</div>
						<div class="tbl_spec_dolj">Уролог, андролог, сексолог, <br>врач высшей категории</div>
						<a href="/alekseev-aleksandr-lvovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
				<td>
						<img src="../images/foto_5.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Хмелевский<br>
							Игорь<br>
							Станиславович
						</div>
						<div class="tbl_spec_dolj">Уролог-андролог. <br>Врач 1 категории</div>
						<a href="/hmelevskii-igor-stanislavovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
		</tbody></table>


<h2>Стоимость услуг:</h2>

<table class="tbl_price">
	<tbody>
		<thead>
		<tr>
			<td>Наименование услуги</td>
			<td align="center">Стоимость руб.</td>
		</tr></thead>
		<tr>
			<td>Прием врача</td>
			<td class="price" align="center">1 000</td>
		</tr>
		<tr>
			<td>Назначение лечения</td>
			<td class="price" align="center">от 2 500</td>
		</tr>
	</tbody>
</table>




<p>Конечно это не у всех так, известны примеры, когда у семидесятилетнего сексуальная жизнь ярче, нежели скажем сорокалетнего мужчины, главное тут иметь здоровое психическое и физиологическое здоровье.</p>

<p>Хронические заболевания, нервные срывы, гормональный сбой, нарушение кровотока – все это может привести к снижении потенции. Так же большое значение тут играет регулярная половая жизнь, ведь у мужчин, которые ведут регулярную половую жизнь, снижение потенции встречается реже, нежели у мужчин с нерегулярным сексом.</p>

<p>Так же причиной снижения потенции являются различные половые инфекции, даже после успешного выздоровления, они могут влиять на потенцию. Либо же недолеченные заболевания мужской половой системы уретрит, простатит и т.п.</p>

<p>Так же известным врагом потенции является алкоголь, от употребления алкоголя клетки яичек просто погибают, резко уменьшается число активных сперматозоидов, и замедляется взаимодействие между половыми органами и мозгами.</p>

<p><span class="bold">Основные причины снижения потенции:</span></p>

<ul class="list">
	<li>сахарный диабет</li>
	<li>алкоголь, наркотики, курение</li>
	<li>нервные срывы, стрессы</li>
	<li>хроническое недосыпание, плохая экология</li>
	<li>нарушения эндокринной системы</li>
	<li>артериальная гипертензия</li>
	<li>плохое неправильное питание</li>
</ul>

<p>На сегодняшний день нет мужчин, которые не сталкивались бы с вышесказанными проблемами, поэтому за своим здоровьем необходимо тщательно следить и при первых признаках обращаться к специалисту, чем раньше обратитесь с лечение, тем быстрее решится проблема.</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li>
		<a href="/konsultatsiya-androloga/">Консультация андролога</a>, 
		<a href="/erektilnaya-disfunkciya/">Эректильная дисфункция</a>, 
		<a href="/uskorennoe-semyaizverzhenie/">Ускоренное семяизвержение</a>, 
		<a href="/lecheniye-muzhskogo-besplodiya/">Бесплодие</a>
	</li>
</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>