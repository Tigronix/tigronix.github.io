<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="description" lang="ru" content="" />
<meta name="keywords" lang="ru" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
<title>���� ������ ����������!</title>
<meta http-equiv="refresh" content="5; URL=/">
<link rel="icon" href="http://xn----8sbgfewnk4akj.xn--80adxhks/favicon.ico" type="image/x-icon" />
<link href="http://xn----8sbgfewnk4akj.xn--80adxhks/css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content content_main">
	
		<div class="sucess_title">
			<span>���� ������ ����������!</span>
			���� ��������� �������� � ���� <br />����� 1 ������.<br />
			�������!
		</div><!--/success_title-->
			
	</div><!--/content-->
	
	<div class="clr"></div>
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">
	
	<?php include("blocks/footer.php"); ?>
	
</div><!--/footer-->


<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="/js/lightbox.js"></script>
<script type="text/javascript" src="/js/custom.js"></script>
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter33415188 = new Ya.Metrika({
                    id:33415188,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true,
                    webvisor:true,
                    trackHash:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/33415188" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>