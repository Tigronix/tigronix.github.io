﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Ускоренное семяизвержение</title>
<meta name="description" lang="ru" content="Ускоренное семяизвержение" />
<meta name="keywords" lang="ru" content="Ускоренное семяизвержение" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/konsultatsiya-androloga/">Консультация андролога</a></li> <li>Ускоренное семяизвержение</li></ul>
		
		
		
		<div class="rside_txt">
		
			
	        		<h1>Ускоренное семяизвержение</h1>

<table class="tbl_spec tbl_spec_2">
			<tbody><tr>
				<td width="419">
						<img src="../images/foto_2.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Алексеев<br>
							Александр<br>
							Львович
						</div>
						<div class="tbl_spec_dolj">Уролог, андролог, сексолог, <br>врач высшей категории</div>
						<a href="/alekseev-aleksandr-lvovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
				<td>
						<img src="../images/foto_5.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Хмелевский<br>
							Игорь<br>
							Станиславович
						</div>
						<div class="tbl_spec_dolj">Уролог-андролог. <br>Врач 1 категории</div>
						<a href="/hmelevskii-igor-stanislavovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
			
		</tbody></table>

<h2>Стоимость услуг:</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>

	<tbody>
		<tr>
			<td>Прием врача</td>
			<td class="price">1 000</td>
		</tr>
		<tr>
			<td>Назначение лечения</td>
			<td class="price">от 2 500</td>
		</tr>
	</tbody>
</table>



<p>Ускоренное семяизвержение – это наиболее распространенное половое расстройство. По количествам жалоб его можно сравнить только с эректильной дисфункцией, то есть с импотенцией. Сколько длится нормальный половой акт? Дать точный ответ на этот вопрос невозможно, однако большинство специалистов сошлись на том, что средняя продолжительность полового акта составляет три минуты. Этот промежуток времени не требует медицинского вмешательства.</p>

<p>Данный показатель имеет свойство колебаться в разные стороны. На это влияет физическая и психологическая усталость, прием лекарств и алкоголя.</p>

<p>Давайте рассмотрим основные причины данной проблемы, препятствующей множеству мужчин наслаждаться сексуальной жизнью.</p>

<p>В юношеском возрасте многие молодые люди страдают преждевременной эякуляцией. Это обусловлено частой сменой партнерш, и проходит при накоплении определенного опыта.</p>

<p>Есть целый ряд причин, по которым может происходить преждевременная эякуляция. Это и психологические факторы, и нерегулярная половая жизнь, множественные страхи, конфликты на сексуальной почве, гиперчувствительные эрогенные зоны, различные травмы, употребление медицинских препаратов и алкоголя, нездоровый образ жизни.</p>

<p>В результате всех этих причин появляются проблемы сексуального характера. Статистика показывает, что каждый пятый мужчина страдает сексуальным расстройством. Некоторые занимаются самолечением, обращаются к нетрадиционным методам лечения. Однако это не приносит или приносит кратковременный эффект.</p>

<p>Наши высококвалифицированные врачи помогут Вам решить проблемы сексуального характера. Наши сотрудники смогут быстро диагностировать причину расстройства и назначат курс лечения. Мы гарантируем полную конфиденциальность и индивидуальный подход к каждому пациенту!</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li>
		<a href="/konsultatsiya-androloga/">Консультация андролога</a>, 
		<a href="/erektilnaya-disfunkciya/">Эректильная дисфункция</a>, 
		<a href="/snizhenie-potencii/">Снижение потенции</a>, 
		<a href="/lecheniye-muzhskogo-besplodiya/">Бесплодие</a>
	</li>
</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>