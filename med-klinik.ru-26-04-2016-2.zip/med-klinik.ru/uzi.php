﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>УЗИ в Москве на Авиамоторной ВАО, ЮВАО</title>
<meta name="description" lang="ru" content="УЗИ в Москве на Авиамоторной ВАО, ЮВАО" />
<meta name="keywords" lang="ru" content="узи" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li>Узи</li></ul>
		
		
		
		<div class="rside_txt">
		
			
	        		<h1>Узи в Москве</h1>

<div class="doc_info">
			
						<table class="tbl_doc_info">
							<tbody><tr>
								<td width="469">
									<img src="../images/foto_15.jpg" width="165" height="186" alt="img">
									<div class="tbl_spec_fio">
										Каримова <br />Галина <br />Михайловна
									</div>
									<div class="tbl_spec_dolj">Врач ультразвуковой диагностики, <br />врач высшей категории</div>
								</td>
								<td width="333" class="tbl_doc_info_right">
									<span class="bold">Записаться на прием можно:</span><br>
									
									На сайте:
									
									<div class="arrow_bot"></div>
									
									<span class="btn_zapis_wrap">
										<a href="/zayavka/" class="btn_zapis">Онлайн запись на прием</a>
									</span>
									<div class="tbl_doc_info_contact">
										По телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
									</div>
								</td>
							</tr>
						</tbody></table>
					
			</div>

<p><a href="/uzi-ginekologicheskoye/">УЗИ гинекологическое</a></p>

<p><a href="/uzi-organov-bryushnoy-polosti/">УЗИ органов брюшной полости</a></p>

<p><a href="/uzi-po-beremennosti/">УЗИ по беременности</a></p>

<p><a href="/uzi-organov-malogo-taza/">УЗИ органов малого таза</a></p>

<p><a href="/ultrazvukovaya-diagnostika/">Ультразвуковая диагностика</a></p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">

	<li><a href="/uzi-urologicheskoe/">Урология</a></li>
	<li><a href="/molochnye-zhelezy/">Молочные железы</a>, 
	<a href="/shchitovidnaya-zheleza/">Щитовидная железа</a></li>
</ul>

</div><!--/rside_txt-->

<div class="lside">

		

			<?php include("blocks/lside.php"); ?>

		

		</div><!--/lside-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
<?php include("blocks/slider_top.php"); ?>
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>