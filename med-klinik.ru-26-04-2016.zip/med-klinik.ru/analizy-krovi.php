<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Анализы крови в Москве - анализы крови на грипп, на гормоны.</title>
<meta name="description" lang="ru" content="Общий и биохимический  анализ крови в Москве в медклинике на Авиамоторной. Виды исследований. Цены на анализы крови. Контакты" />
<meta name="keywords" lang="ru" content="Анализы крови" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/sdat-analizy/">Анализы</a></li> <li>Анализы крови</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
			
	        		<h1>Анализы крови в Москве</h1>

<p>По состоянию крови человека можно определить любые, даже самые незначительные изменения организма, определить большинство заболеваний еще на самих ранних стадиях их развития. Для определения различных видов заболеваний и патологий используются разные методы, если нужен анализ крови. В любом случае анализ подразумевает забор крови из вены или пальца при использовании специальной иглы или стерильных насосов соответственно. В нашем современном центре в Москве на Авиаматорной проводятся все виды анализов крови: на грипп, на свиной грипп, на гормоны по умеренным ценам. Работа квалифицированных специалистов и современного оборудования позволяют нашим клиентам получать точные результаты анализов в кратчайшие сроки.</p>

<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>

<h2>БИОХИМИЧЕСКИЕ ИССЛЕДОВАНИЯ КРОВИ</h2>

<table class="tbl_price">
	<thead>
		<tr>
			<td>Вид анализа</td>
			<td align="center">Цена руб.</td>
			<td align="center">Срок исп.</td>
		</tr>
		</thead>
	<tbody>
		<tr>
			<td>Альбумин</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Общий билирубин</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Прямой билирубин</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Непрямой билирубин</td>
			<td align="center" class="price">160</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Триглицериды</td>
			<td align="center" class="price">160</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Холестерин общий</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Глюкоза</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Креатинин</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Мочевая кислота</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Мочевина</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Общий белок</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Белковые фракции</td>
			<td align="center" class="price">260</td>
			<td class="price">2 р/д</td>
		</tr>
		<tr>
			<td>Протеинограмма</td>
			<td align="center" class="price">520</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Общий белок+криоглобулин</td>
			<td align="center" class="price">320</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Липидный обмен</td>
			<td align="center" class="price">590</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Холестерин низк плот (ЛПОНП)</td>
			<td align="center" class="price">320</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Холестерин высок плот (ЛПВП)</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Аполипротеин А1</td>
			<td align="center" class="price">390</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Аполипротеин В</td>
			<td align="center" class="price">390</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Липопротеин (а)</td>
			<td align="center" class="price">390</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Щелочная фосфатаза</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Кислая фосфатаза</td>
			<td align="center" class="price">300</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Холинэстераза</td>
			<td align="center" class="price">180</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Липаза</td>
			<td align="center" class="price">320</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Амилаза панкреатическая</td>
			<td align="center" class="price">260</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Альфа амилаза</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Гаммаглютамилтранспептидаза (ГГТ)</td>
			<td align="center" class="price">160</td>
			<td class="price">1 р/д</td>
		</tr>
		<tr>
			<td>Аланинаминотрансфераза (АЛТ)</td>
			<td align="center" class="price">150</td>
			<td class="price">1 р/д</td>
		</tr>
	</tbody>
</table>



<h2>Виды исследований:</h2>

<p>Такой вид исследования, как общий (ОАК) – самый часто проводимый вид анализа. Результаты позволяют установить наличие патологических изменений в человеческом организме, даже если те не подают никаких внешних  признаков и заболевание находится только на начальной стадии. Любые заболевания кровеносной системы, инфекционные и воспалительные процессы можно определить с помощью ОАК. Также с помощью ОАК можно наблюдать за процессом лечения, назначенного врачом и эффективности его протекания.</p>

<p><img style="width: 350px; height: 207px; margin: 10px; float: left;" src="../img/analiz-krovi1.jpg" alt="анализы крови" /><img style="width: 350px; height: 207px; margin: 10px; float: left;" src="../img/obshh-analiz-krovi-1.jpg" alt="анализ крови" /></p>

<div class="clr"></div>

<p>Анализ на биохимию – этот анализ незаменим при общей оценке работы всех органов и систем организма или работы отдельных органов и систем. Взятие ОАК на биохимию позволяет выявить заболевания почек, печени, желчного пузыря, селезенки и поджелудочного пузыря еще в самом начале развития заболевания.<br />
Анализ на сахар – с его помощью определяется содержание глюкозы в крови. Средний показатель этой концентрации у здорового человека составляет 3,3-3,5 миллимоля. К исследованию нужно подготовиться. Кровь для этого анализа берется из пальца пациента и строго натощак. Всем пациентам, старше 40 лет, этот анализ выполняется амбулаторно, у более молодых пациентов определяется наличие сахарного диабета.</p>

<p>Исследование на состояние иммунитета – проводится с целью определения количества иммунных клеток. Позволяет получить необходимые сведения о состоянии иммунитета и определить иммунодефицит и его последствия. При определении острого и хронического патологического процесса определяется наличие белков иммуноглобулина.</p>

<p>Анализ на серологию – используется для определения наличия антител к различным вирусам и бактериям, позволяет определить инфекционные заболевания кровеносной системы. Также при анализе на серологию определяется группа и резус-фактор крови.</p>

<p>Коагулограмма (гемостазиограмма) – исследование работы системы свертывания крови. Позволяет своевременно устанавливать причины проблем со свертыванием крови, что является неотъемлемой составляющей постановления правильного лечения и назначения лечения. Исследование на онкомаркеры –  позволяет обнаружить в крови белки, которые образуются онко-клетками, но их наличие еще не означает раковых заболеваний у человека, ведь белки могут быть образованы и доброкачественными опухолями. Обнаружение в крови онкомаркеров свидетельствует о возникновении опухолевых новообразований в организме или развитии уже существующих. Пораженные клетки значительно отличаются от здоровых по своей форме и рабочим функциям.</p>

<p>Самый важный этап лечения онкологических заболеваний – своевременно установление диагноза и назначение лечения, а взятие ОАК на онкомаркеры сильно этому способствует.</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li><a href="/sdat-analizy/">Анализы</a></li>

	<li>
	<a href="/obsledovaniye-na-ippp/">ПЦР-диагностика</a>, 
	<a href="/analizy-na-polovyye-infektsii/">Анализы на половые инфекции</a>, 
	<a href="/analizy-na-infekcii-u-zhenshchin/">Анализы на инфекции у женщин</a>, 
	<a href="/analizy-na-infektsii-u-muzhchin/">Анализы на инфекции у мужчин</a>, 
	<a href="/analizy-na-gormony/">Анализы на гормоны</a>, 
	<a href="/analizy-anonimno/">Анализы анонимно</a>
	</li>

	<li>
	<a href="/analiz-mochi/">Анализ мочи</a>, 
	<a href="/mikroskopiya/">Микроскопия крови</a>, 
	<a href="/mikrobiologiya/">Микробиологические исследования</a>, 
	<a href="/citologiya/">Цитологическое исследование</a>, 
	<a href="/gistologiya/">Гистология</a>
	</li>
</ul>

</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>
