		<div class="lic">
			<a href="http://www.med-klinik.ru/images/img_16.png"><img src="http://www.med-klinik.ru/images/img_15.png" width="57" height="83" alt="img" /></a>
			<p>Лицензия на осуществление<br />
				медицинской деятельности № ЛО-77-01-007951<br />
				выдана ООО Медицинский центр «М-сервис»<br />
				2 апреля 2014 г.
			</p>
		</div><!--/lic-->
		
		<ul class="nav_bot">
			<li><a href="/klinika-na-aviamotornoy/">О компании</a></li>
			<li><a href="http://www.med-klinik.ru/#nashi_uslugi">Наши услуги</a></li>
			<li><a href="/kontakty/">Контакты</a></li>
			<li><a href="/nashi-specialisty/">Наши специалисты</a></li>
		</ul><!--/nav_bot-->
		
		<div class="phone_bot">+7 (495) 256-38-00</div>
		
		<div class="time_bot">
			ПН - ПТ 9: 00 - 21: 00<br />
			СБ - ВС 9: 00 - 19: 00
		</div><!--/time_bot-->
		
		<div class="line"></div>
		
		<div class="copy"><a href="/sitemap/" class="map">&copy;</a> 1998-2016 Мед клиника «Логон»</div>
		
		<div class="soc_bot"></div>
		
		<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter35262070 = new Ya.Metrika({
                    id:35262070,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true,
                    webvisor:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/35262070" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
		
		<div class="create">Создание и продвижение сайта - <a href="http://www.es-studio.ru/" target="_blank">ES-studio.ru</a></div>