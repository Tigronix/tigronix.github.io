		<a href="/" class="logo"></a>
		
		<div class="address_top">
		
			<div class="address_top_title">Обращайтесь в нашу клинику</div>
			
			<a href="/kontakty/" class="address_top_metro">Авиамоторная <span>(3 мин. пешком)</span></a>
			
			<div class="address_top_txt">г. Москва, шоссе Энтузиастов, д. 11 К1</div>
		
		</div><!--/address_top-->
		
		<div class="slider_actions">
		
			<ul class="bxslider">
				<li>
					<img src="http://www.med-klinik.ru/images/img_1.png" width="302" height="211" alt="img" />
					<span class="slider_actions_txt">
						<span class="slider_actions_title">ВНИМАНИЕ АКЦИЯ!</span>
						<span class="slider_actions_desc">
							При онлайн записи с сайта <br />на первичный прием <span class="bold_red">скидка до 30%</span>
						</span>
						<span class="btn_zapis_wrap">
							<a href="/zayavka/" class="btn_zapis">Онлайн запись на прием</a>
						</span>
					</span>
				</li>
				<li>
					<img src="http://www.med-klinik.ru/images/img_2.png" width="302" height="211" alt="img" />
					<span class="slider_actions_txt">
						<span class="slider_actions_title">ВНИМАНИЕ АКЦИЯ!</span>
						<span class="slider_actions_desc">
							<span class="blue_txt">"Здоровые выходные"</span>
							Для всей семьи в воскресенье <br />на первичный прием <span class="bold_red">скидка до 30%</span>
						</span>
						<span class="btn_zapis_wrap">
							<a href="/zayavka/" class="btn_zapis">Онлайн запись на прием</a>
						</span>
					</span>
				</li>
				<li>
					<img src="http://www.med-klinik.ru/images/img_3.png" width="302" height="211" alt="img" />
					<span class="slider_actions_txt">
						<span class="slider_actions_title">ВНИМАНИЕ!</span>
						<span class="slider_actions_desc">
							Мы рады сообщить что теперь<br />
							наш медицинский центр<br />
							выдает медицинские книжки
						</span>
						<span class="slider_actions_price">от 1 500 руб.</span>
					</span>
				</li>
			</ul><!--/bxslider-->
		
		</div><!--/slider_actions-->