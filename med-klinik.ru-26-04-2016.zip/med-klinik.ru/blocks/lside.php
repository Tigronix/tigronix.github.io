			<div class="address_top_title">Основные направления</div>
		
			<ul class="nav_left">
				<li><a href="/konsultatsiya-ginekologa-v-moskve/">Консультация гинеколога</a></li>
				<li><a href="/konsultacia_urologa/">Консультация уролога</a></li>
				<li><a href="/priem-dermatologa/">Венерология</a></li>
				<li><a href="/konsultatsiya-androloga/">Консультация андролога</a></li>
				<li><a href="#">Консультация терапевта</a></li>
				<li><a href="/klinicheskii--psiholog/">Клинический психолог</a></li>
				<li><a href="/stomotologiya/">Стоматология</a></li>
				<li><a href="/uzi/">УЗИ</a></li>
				<li><a href="/analizy/">Анализы</a></li>
			</ul><!--/nav_left-->