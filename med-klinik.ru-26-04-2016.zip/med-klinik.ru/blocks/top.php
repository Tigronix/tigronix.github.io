<div class="top_in">
	
	<ul class="nav_top">
		<li><a href="/klinika-na-aviamotornoy/">О медцентре</a></li>
		<li><a href="/nashi-specialisty/">Наши специалисты</a></li>
		<li><a href="http://www.med-klinik.ru/#nashi_uslugi">Наши услуги</a></li>
		<li><a href="/kontakty/">Контакты</a></li>
	</ul><!--/nav_top-->
	
	<a href="/zayavka/" class="btn_top">Записаться на прием</a>
	
	<div class="phone_top">+7 (495) 256-38-00</div>
	
</div><!--/top_in-->