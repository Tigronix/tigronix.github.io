﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Цистит</title>
<meta name="description" lang="ru" content="Цистит" />
<meta name="keywords" lang="ru" content="Цистит" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/konsultacia_urologa/">Консультация уролога</a></li> <li>Цистит</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
			
	        		<h1>Цистит</h1>
					
					<p>Воспаление мочевого пузыря, которым урологи обозначают симптоматическую инфекцию. Цистит связан с воспалительными процессами в слизистой оболочке мочевого пузыря, функциональными нарушениями и изменениями нормального состава мочи. Симптоматика зависит от стадии и формы заболевания. При остром цистите отмечаются жалобы на учащенное мочеиспускание (2 и более раза в течение часа), боли внизу живота, которые усиливаются и усугубляются резями при мочеиспускании, повышение температуры тела. При хронической форме заболевания симптомы могут отсутствовать.</p>
					
					<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>

			<table class="tbl_spec tbl_spec_2">
			<tbody><tr>
				<td width="419">
						<img src="../images/foto_2.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Алексеев<br>
							Александр<br>
							Львович
						</div>
						<div class="tbl_spec_dolj">Уролог, андролог, сексолог, <br>врач высшей категории</div>
						<a href="/alekseev-aleksandr-lvovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
				<td width="417">
						<img src="../images/foto_3.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Диденко<br>
							Елена<br>
							Юрьевна
						</div>
						<div class="tbl_spec_dolj">Дерматовенеролог, уролог, андролог.<br>Врач 1 категории</div>
						<a href="/didenko-elena-yurevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
			<tr>
			
			<td>
						<img src="../images/foto_5.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Хмелевский<br>
							Игорь<br>
							Станиславович
						</div>
						<div class="tbl_spec_dolj">Уролог-андролог. <br>Врач 1 категории</div>
						<a href="/hmelevskii-igor-stanislavovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
		</tbody></table>


<p>Мы проводим диагностику и лечение цистита. В медицинском центре работают урологи, врачи с большим опытом практической работы.  Наши врачи  адекватно оценивают состояние вашего здоровья и назначают индивидуальное грамотное лечение, принимая во внимание Ваши индивидуальные особенности (возраст, давность заболевания, степень запущенности, выраженности симптомов, наличия сопутствующих заболеваний, состояния иммунитета). При лечении цистита мы используем только качественные медикаменты, а диагностика проводится с помощью современного оборудования.</p>

<p>Запись по телефону:   +7 (495) 256-38-00</p>

<p>Рекомендуем обратиться к врачу за консультацией</p>

<h2>Стоимость услуг:</h2>

<table class="tbl_price">
	<thead>
		<tr>
			<td width="603">Наименование услуги</td>
			<td width="197" align="center">Стоимость руб.</td>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>Прием уролога, осмотр, консультация</td>
			<td align="center" class="price">1000</td>
		</tr>
		<tr>
			<td>Мазок</td>
			<td align="center" class="price">450</td>
		</tr>
		<tr>
			<td>УЗИ мочевого пузыря</td>
			<td align="center" class="price">700</td>
		</tr>
		<tr>
			<td>Общий анализ мочи</td>
			<td align="center" class="price">260</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
	</tbody>
</table>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li>
		<a href="/mochekamennaya-bolezn/">Мочекаменная болезнь</a>
	</li>
	<li>
		<a href="/pochechnaya-kolika/">Почечная колика</a>, 
		<a href="/uretrit/">Уретрит</a>, 
		<a href="/prostatit/">Простатит</a>
	</li>
	
	<li>
		<a href="/xronicheskii-prostatit/">Хронический простатит</a>, 
		<a href="/prichiny-prostatita/">Причины простатита</a>, 
		<a href="/simptomy-prostatita/">Симптомы простатита</a>, 
		<a href="/diagnostika-prostatita/">Диагностика простатита</a>, 
		<a href="/lecheniye-prostatita-v-moskve/">Лечение простатита</a>, 
		<a href="/infekcii-mochepolovyh-putei/">Инфекции мочеполовых путей</a>
	</li>
</ul>

</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>
