﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Эндоцервицит лечение в Москве</title>
<meta name="description" lang="ru" content="Эндоцервицит лечение цена от 1000 руб." />
<meta name="keywords" lang="ru" content="Эндоцервицит" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/konsultatsiya-ginekologa-v-moskve/">Консультация гинеколога</a></li> <li>Эндоцервицит</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
			
	        		<h1>Эндоцервицит лечение в Москве</h1>

<p>ЭНДОЦЕРВИЦИТ, ЦЕРВИЦИТ  - воспалительное заболевание шейки матки, наиболее частое и типичное проявление ИППП у женщин. Может возникать одновременно с вульвовагинитом, но, как правило, является его следствием. Цервицит могут вызвать стафилококки, стрептококки и другие неспецифические микробы, но чаще это микоплазмы, хламидии, гонококки, гарднереллы.</p>

<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>

<h2>Прием ведут:</h2>

		<table class="tbl_spec tbl_spec_2">
				<tr>
					<td>
						<img src="../images/foto_4.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Букинская<br>
							Елена<br>
							Владимировна
						</div>
						<div class="tbl_spec_dolj">Акушер-гинеколог, врач <br>высшей категории</div>
						<a href="/bukinskaya-elena-vladimirovna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					<td>
						<img src="../images/foto_7.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Петрашко<br>
							Татьяна<br>
							Николаевна
						</div>
						<div class="tbl_spec_dolj">Врач акушер гинеколог, <br>врач высшей категории</div>
						<a href="/petrashko-tatyana-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					
					</tr>
					<tr>
				<td class="center_td">
					<img src="../images/foto_8.png" width="165" height="186" alt="img">
					<div class="tbl_spec_fio">
						Шиленина<br>
						Елена<br>
						Николаевна
					</div>
					<div class="tbl_spec_dolj">Акушер-гинеколог, <br>врач высшей категории</div>
					<a href="/shilenina-elena-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>

<p>Клинически цервицит проявляеться гноевидными выделениями  с неприятным запахом, тянущие боли внизу живота. Может протекать малосимптомно или бессимптомно. При хроническом течении цервицит приводит к  эрозии шейки матки, диспластическим изменениям эпителия. Это очень опасно т.к. значительно повышает  риск развития онкологических заболеваний шейки матки.</p>

<p><span class="bold">Только наши специалисты с успехом проводят диагностику и лечение данного заболевания</span></p>

<p>Диагностика и лечение цервицита в Москве основана на гинекологическим осмотре и данных микроскопических и микробиологических исследований.</p>





<h2>Стоимость услуг:</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>

	<tbody>
		<tr>
			<td>
			Прием гинеколога, осмотр, консультация
			</td>
			<td align="center" class="price">
			1000
			</td>
		</tr>
		<tr>
			<td>
			Мазок
			</td>
			<td align="center" class="price">
			450
			</td>
		</tr>
		<tr>
			<td>
			ПЦР диагностика
			</td>
			<td align="center" class="price">
			240
			</td>
		</tr>
		<tr>
			<td>
			Бак посев
			</td>
			<td align="center" class="price">
			от 590
			</td>
		</tr>
		<tr>
			<td colspan="2">
			&nbsp;
			</td>
		</tr>
	</tbody>
</table>

<p>Не занимайтесь самолечением!</p>

<p>Лечение – комплексное, включает  антибактериальную терапию, иммуностимулирующую терапию, обработку влагалища и шейки матки, витаминотерапия.</p>

<p>Запись на прием обязательна !</p>

<p><span class="bold"><span style="font-size:18px;">Тел : +7 (495) 256-38-00</span></span></p>

<p><span class="bold">Без предварительной записи</span> Вас могут принять на прием, только в порядке общей очереди, если имеются свободные места.</p>

<p>ОСЛОЖНЕНИЯ  воспалительных заболеваний женских половых органов:</p>

<ul class="list">
	<li>бесплодие</li>
	<li>расстройства половой и менструальной функции женщины</li>
	<li>самопроизвольные выкидыши и преждевременные роды</li>
	<li>осложненное течение беременности: внутриутробное инфицирование плода</li>
</ul>

<p>Своевременная профилактика и лечение воспалительных заболеваний избавит не только вас, но и ваших близких и главное, ваших детей от больших проблем</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
<li><a href="/vedenie-beremennosti-ceny/">Беременность</a>, 
	<a href="/lecheniye-bakterialnogo-vaginoza/">Вагиноз</a>, 
	<a href="/bartolinit/">Бартолинит</a>, 
	<a href="/salpingooforit-adneksit/">Аднексит</a>, 
	<a href="/endometrit-metroendometrit/">Эндометрит</a>, 
	<a href="/endometrioz/">Эндометриоз</a>, 
	<a href="/eroziya-sheiki-matki/">Эрозия шейки матки</a>, 
	<a href="/infekcii-zhenskoi-polovoi-sistemy/">Инфекции женской половой системы</a>, 
	<a href="/proyavlenie-gormonalnyh-narushenii/">Гормональные нарушения</a>, 
	<a href="/diagnostika-besplodiya/">Бесплодие</a>, 
	<a href="/klimaks/">Климакс</a>, 
	<a href="/narushenie-menstrualnogo-cikla/">Нарушение менструального цикла</a>, 
	<a href="/kontracepciya/">Контрацепция</a>, 
	<a href="/medikomentoznyi-abort/">Медикаментозный аборт </a>
</li>
<li><a href="/diagnostika-bakterialnogo-vaginoza/">Диагностика бактериального вагиноза</a>, 
	<a href="/etiologiya-bakterialnogo-vaginoza/">Этиология бактериального вагиноза</a>, 
	<a href="/zarazhenie-bakterialnym-vaginozom/">Заражение бактериальным вагинозом</a>, 
	<a href="/klinika-bakterialnogo-vaginoza/">Клиника бактериального вагиноза</a>, 
	<a href="/bakterialnyi-vaginoz-oslozhneniya/">Бактериальный вагиноз - осложнения </a>
</li>
<li><a href="/prichiny-gormonalnyh-narushenii/">Причины гормональных нарушений</a>, 
	<a href="/lechenie-i-diagnostika-gormonalnyh-narushenii/">Лечение и диагностика гормональных нарушений </a>
</li>
<li><a href="/lecheniye-besplodiya-v-moskve/">Лечение бесплодия</a>, 
	<a href="/lecheniye-zhenskogo-besplodiya/">Лечение женского бесплодия</a>
</li>
<li>
	<a href="/farmabort/">Фармаборт</a>, 
	<a href="/bezoperacionnyi-abort/">Безоперационный аборт</a>, 
	<a href="/abort-tabletkami/">Аборт таблеткам</a>
</li>

</ul>

</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>