﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Эректильная дисфункция</title>
<meta name="description" lang="ru" content="Эректильная дисфункция" />
<meta name="keywords" lang="ru" content="Эректильная дисфункция" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/konsultatsiya-androloga/">Консультация андролога</a></li> <li>Эректильная дисфункция</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
			
	        		<h1>Эректильная дисфункция</h1>
					
					<p>На сегодняшний день многие люди мужские неудачи в половой жизни называют импотенцией, но это не совсем верно правильным такое состояние называется эректильная дисфункция. С 1992 года такое мужское состояние принято называть эректильная дисфункция, оно включает в себя не только невозможность удерживать половой член в состоянии эрекции, но и ослабление полового влечения (либидо).</p>

<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>

<h2>Прием ведут:</h2>

<table class="tbl_spec tbl_spec_2">
<tbody><tr>
				<td width="419">
						<img src="../images/foto_2.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Алексеев<br>
							Александр<br>
							Львович
						</div>
						<div class="tbl_spec_dolj">Уролог, андролог, сексолог, <br>врач высшей категории</div>
						<a href="/alekseev-aleksandr-lvovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>

<td>
						<img src="../images/foto_5.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Хмелевский<br>
							Игорь<br>
							Станиславович
						</div>
						<div class="tbl_spec_dolj">Уролог-андролог. <br>Врач 1 категории</div>
						<a href="/hmelevskii-igor-stanislavovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
		</tbody></table>


<h2>Стоимость услуг:</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>
	<tbody>
		<tr>
			<td>Прием врача</td>
			<td align="center" class="price">1 000</td>
		</tr>
		<tr>
			<td>Назначение лечения</td>
			<td align="center" class="price">от 2 500</td>
		</tr>
	</tbody>
</table>




<p>Принято считать, что эта проблема касается только мужчин старшей вековой группы, но это не совсем так, такие нарушения случаются и у молодых людей, этому способствует переутомления на работе, психологические проблемы, нервные срывы, соматические заболевания, поэтому очень важно в таких случаях не стеснятся, и своевременно обратится к врачу.</p>

<p>Известно два вида эриктильной дисфункции первичная и вторичная. Первичная эриктильная дисфункция, так же ее называют врожденная, характерна тем, что у мужчины ни разу не получилось совершить половой акт, такое бывает крайне редко. Вторичная эректильная дисфункция, это когда у мужчины все было хорошо в сексуальной жизни и в один момент начались проблемы с эрекцией. Бывает слабая эрекция, которая не позволяет совершить полноценный половой акт, а иногда сильная эрекция, которая быстро проходит при близости.</p>

<p><span class="bold">Причины вызывающие эректильную дисфункцию:</span></p>

<ul class="list">
	<li>нарушения эндокринной системы</li>
	<li>нарушения неврологической системы</li>
	<li>хронический простатит</li>
	<li>сахарный диабет</li>
	<li>последствия медикаментозной терапии</li>
	<li>изменения тканей полового члена.</li>
</ul>

<p>Очень важно не тянуть, не стеснятся, а своевременно обратится к доктору, который назначит необходимое лечение и все у вас будет хорошо в сексуальной жизни!</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li>
		<a href="/konsultatsiya-androloga/">Консультация андролога</a>, 
		<a href="/snizhenie-potencii/">Снижение потенции</a>, 
		<a href="/uskorennoe-semyaizverzhenie/">Ускоренное семяизвержение</a>, 
		<a href="/lecheniye-muzhskogo-besplodiya/">Бесплодие</a>
	</li>
</ul>

</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>