﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Этиология бактериального вагиноза</title>
<meta name="description" lang="ru" content="Этиология бактериального вагиноза" />
<meta name="keywords" lang="ru" content="Этиология бактериального вагиноза" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/lecheniye-bakterialnogo-vaginoza/">Вагиноз</a></li> <li>Этиология бактериального вагиноза</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
			
	        		<h1>Этиология бактериального вагиноза</h1>
					
					<p>Бактериальный вагиноз характеризуется изменениями экосистемы влагалища, выражающимися в замещении доминирующих в микрофлоре влагалища микроорганизмов рода Lactobacillus ассоциацией различных бактерий, в том числе Gardnerella vaginalis, анаэробов (Bacteroides, Prevo-tella, Porphyromonas, Peptostreptococcus, Mobiluncus) и Mycoplasma hominis. Ранее полагали, что болезнь вызывается гарднереллой на основании идентификации микроорганизма у женщин с бактериальным вагинозом.</p>


<div class="zapis_txt">
			Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
		</div>
		
		<h2>Прием ведут:</h2>

		<table class="tbl_spec tbl_spec_2">
				<tr>
					<td>
						<img src="../images/foto_4.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Букинская<br>
							Елена<br>
							Владимировна
						</div>
						<div class="tbl_spec_dolj">Акушер-гинеколог, врач <br>высшей категории</div>
						<a href="/bukinskaya-elena-vladimirovna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					<td>
						<img src="../images/foto_7.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Петрашко<br>
							Татьяна<br>
							Николаевна
						</div>
						<div class="tbl_spec_dolj">Врач акушер гинеколог, <br>врач высшей категории</div>
						<a href="/petrashko-tatyana-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					
					</tr>
					<tr>
				<td class="center_td">
					<img src="../images/foto_8.png" width="165" height="186" alt="img">
					<div class="tbl_spec_fio">
						Шиленина<br>
						Елена<br>
						Николаевна
					</div>
					<div class="tbl_spec_dolj">Акушер-гинеколог, <br>врач высшей категории</div>
					<a href="/shilenina-elena-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>

<p>
Однако в дальнейшем, было установлено, что более 50% женщин без признаков заболевания оказываются колонизированными гарднереллой. Помимо гарднерелл в вагинальном секрете женщин с бактериальным вагинозом были обнаружены в большом количестве анаэробные бактерии: бактероиды, пептококки, пептострептококки.<br />
<br />
С бактериальным вагинозом также связаны Mobiluncus spp. и Mycoplasma hominis, однако точная роль этих бактерий в этиологии заболевания неизвестна. В процессе метаболизма гарднерелла образует аминокислоты, из которых под влиянием анаэробов образуются летучие амины (путресцин, кадаверин, триэтиламин). Эти амины являются причиной неприятного запаха, напоминающего запах гнилой рыбы.</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
<li><a href="/vedenie-beremennosti-ceny/">Беременность</a>, 
	<a href="/lecheniye-bakterialnogo-vaginoza/">Вагиноз</a>, 
	<a href="/bartolinit/">Бартолинит</a>, 
	<a href="/salpingooforit-adneksit/">Аднексит</a>, 
	<a href="/endometrit-metroendometrit/">Эндометрит</a>, 
	<a href="/endocervicit/">Эндоцервицит</a>, 
	<a href="/endometrioz/">Эндометриоз</a>, 
	<a href="/eroziya-sheiki-matki/">Эрозия шейки матки</a>, 
	<a href="/infekcii-zhenskoi-polovoi-sistemy/">Инфекции женской половой системы</a>, 
	<a href="/proyavlenie-gormonalnyh-narushenii/">Гормональные нарушения</a>, 
	<a href="/diagnostika-besplodiya/">Бесплодие</a>, 
	<a href="/klimaks/">Климакс</a>, 
	<a href="/narushenie-menstrualnogo-cikla/">Нарушение менструального цикла</a>, 
	<a href="/kontracepciya/">Контрацепция</a>, 
	<a href="/medikomentoznyi-abort/">Медикаментозный аборт </a>
</li>
<li><a href="/diagnostika-bakterialnogo-vaginoza/">Диагностика бактериального вагиноза</a>, 
	<a href="/zarazhenie-bakterialnym-vaginozom/">Заражение бактериальным вагинозом</a>, 
	<a href="/klinika-bakterialnogo-vaginoza/">Клиника бактериального вагиноза</a>, 
	<a href="/bakterialnyi-vaginoz-oslozhneniya/">Бактериальный вагиноз - осложнения </a>
</li>
<li><a href="/prichiny-gormonalnyh-narushenii/">Причины гормональных нарушений</a>, 
	<a href="/lechenie-i-diagnostika-gormonalnyh-narushenii/">Лечение и диагностика гормональных нарушений </a>
</li>
<li><a href="/lecheniye-besplodiya-v-moskve/">Лечение бесплодия</a>, 
	<a href="/lecheniye-zhenskogo-besplodiya/">Лечение женского бесплодия</a>
</li>
<li>
	<a href="/farmabort/">Фармаборт</a>, 
	<a href="/bezoperacionnyi-abort/">Безоперационный аборт</a>, 
	<a href="/abort-tabletkami/">Аборт таблеткам</a>
</li>

</ul>

</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>