<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Медицинский центр на Авиамоторной Логон</title>
<meta name="description" content="Медицинский центр на Авиамоторной . Все виды медицинских услуг: гинекология, дерматовенерология, андрология, урология. График работы врачей-специалистов и запись на прием. Новости медклиники. Контакты" />
<meta name="keywords" content="Медицинский центр, Медицинские услуги" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name='yandex-verification' content='5419500d66d0c75a' />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
	
		<div class="time" id="nashi_uslugi">Наша клиника открыта для Вас с <span class="bold_black">ПН - ПТ с 9-00 до 21-00</span>. В <span class="bold_red">СБ - ВС с 9-00 до 19-00</span>. Мы всегда рады вас видеть в нашей клинике!</div><!--/time-->
		
		<div class="title_blue">Основные услуги медицинского центра на Авиамоторной</div>
		
		<table class="services_table">
			<tr>
				<td>
					<div class="services_img">
						<img src="http://www.med-klinik.ru/images/img_4.png" width="180" height="120" alt="img" />
					</div>
					<div class="services_desc">
						<a href="/konsultatsiya-ginekologa-v-moskve/" class="services_link">Гинекология</a>
						<div class="services_title">Услуги специалистов:</div>
						<ul class="services_list">
							<li><a href="/vedenie-beremennosti-ceny/">Беременность,</a> <a href="/diagnostika-bakterialnogo-vaginoza/">диагностика вагиноза,</a> <a href="/bartolinit/">бартолинит,</a><a href="/salpingooforit-adneksit/">аднексит</a></li>
							<li><a href="/endometrit-metroendometrit/">Эндометрит,</a> <a href="/endocervicit/">эндоцервицит,</a> <a href="/endometrioz/">эндометриоз,</a><a href="/diagnostika-besplodiya/">бесплодие</a></li>
							<li><a href="/eroziya-sheiki-matki/">Эрозия шейки матки,</a> <a href="/infekcii-zhenskoi-polovoi-sistemy/">инфекции женской половой системы</a></li>
							<li><a href="/proyavlenie-gormonalnyh-narushenii/">Гармональные нарушения,</a> <a href="/klimaks/">климакс,</a> <a href="/narushenie-menstrualnogo-cikla/">нарушение менструального цикла</a></li>
							<li><a href="/kontracepciya/">Контрацепция,</a> <a href="/medikomentoznyi-abort/">медикаментозный аборт</a></li>
						</ul>
					</div>
				</td>
				<td>
					<div class="services_img">
						<img src="http://www.med-klinik.ru/images/img_5.png" width="180" height="120" alt="img" />
					</div>
					<div class="services_desc">
						<a href="/konsultacia_urologa/" class="services_link">Урология</a>
						<div class="services_title">Услуги специалистов:</div>
						<ul class="services_list">
							<li><a href="/mochekamennaya-bolezn/">Мочекаменная болезнь,</a> <a href="/pochechnaya-kolika/">почечная колика</a></li>
							<li><a href="/uretrit/">Уретрит,</a> <a href="/cistit/">цистит,</a> <a href="/infekcii-mochepolovyh-putei/">инфекции мочеполовых путей</a></li>
							<li><a href="/prostatit/">Простатит,</a> <a href="/diagnostika-prostatita/">диагностика простатита,</a> <a href="/xronicheskii-prostatit/">хронический простатит,</a> <a href="/prichiny-prostatita/">причины простатита,</a> <a href="/simptomy-prostatita/">симптомы простатита,</a><br /><a href="/lecheniye-prostatita-v-moskve/"> лечение простатита</a></li>
						</ul>
					</div>
				</td>
			</tr>
			<tr>
				<td rowspan="2">
					<div class="services_img">
						<img src="http://www.med-klinik.ru/images/img_6.png" width="180" height="120" alt="img" />
					</div>
					<div class="services_desc">
						<a href="/priem-dermatologa/" class="services_link">Венерология, дерматолог</a>
						<div class="services_title">Услуги специалистов:</div>
						<ul class="services_list">
							<li><a href="/diagnostika-kandidoza/">Кандидоз,</a> <a href="/lechenie-mikoplazmoza/">микоплазмос</a> <a href="/diagnostika-khlamidioza/">диагностика хламидиоза</a></li>
							
							<li><a href="/lecheniye-khlamidioza-u-zhenshchin/">Лечение хламидиоза у женщин,</a> <a href="/lecheniye-khlamidioza-u-muzhchin/">лечение хламидиоза у мужчин</a></li>
							
							<li><a href="/diagnostika-gerpesa/">Генитальный герпес,</a> <a href="/lecheniye-genitalnogo-gerpesa/">лечение генитального герпеса</a></li>
							
							<li><a href="/lecheniye-ureaplazmoza-u-zhenshchin/">Уреаплазмоз,</a> <a href="/lecheniye-papillomavirusa/">папилломавирус,</a> <a href="/lechenie-trihomoniaza/">трихомониаз</a></li>
							
							<li><a href="/diagnostika-trikhomoniaza/">Диагностика трихомониаза</a></li>
							
							<li><a href="/lecheniye-gonorei/">Гонорея,</a> <a href="/diagnostika-gonorei/">диагностика гонореи,</a> <a href="/lecheniye-gonorei-u-muzhchin/">лечение гонореи у мужчин</a></li>
							
							<li><a href="/lecheniye-gonorei-u-zhenshchin/">Лечение гонореи у женщин,</a> <a href="/gonoreya-u-detei/">гонорея у детей</a></li>
							
							<li><a href="/etiologiya-gonorei/">Этиология гонореи</a></li>
							
							<li><a href="/etiologiya-sifilisa/">Этиология сифилиса,</a> <a href="/puti-zarazheniya/">пути заражения,</a> <a href="/pervichnyi-period-sifilisa/">первичный период сифилиса,</a> <a href="/vtorichnyi-period-sifilisa/">вторичный период сифилиса,</a> <a href="/tretichnyi-period-sifilisa/">третичный период сифилиса,</a> <a href="/skrytyi-sifilis/">скрытый сифилис,</a> <a href="/neirosifilis/">нейросифилис,</a> <a href="/viscerosifilis/">висцеросифилис,</a> <a href="/vrozhdennyi-sifilis/">врожденный сифилис,</a> <a href="/diagnostika-sifilisa/">диагностика сифилиса</a></li>
							
						</ul>
					</div>
				</td>
				<td height="151">
					<div class="services_img">
						<img src="http://www.med-klinik.ru/images/img_7.png" width="180" height="120" alt="img" />
					</div>
					<div class="services_desc">
						<a href="/konsultatsiya-androloga/" class="services_link">Консультация андролога</a>
						<div class="services_title">Услуги специалистов:</div>
						<ul class="services_list">
							<li><a href="/erektilnaya-disfunkciya/">Эректильная дисфункция,</a> <a href="/snizhenie-potencii/">снижение потенции</a></li>
							
							<li><a href="/uskorennoe-semyaizverzhenie/">Ускоренное семяизвержение,</a> <a href="/lecheniye-muzhskogo-besplodiya/">бесплодие</a></li>
						</ul>
					</div>
				</td>
			</tr>
			<tr>
				<td>
					<div class="services_img">
						<img src="http://www.med-klinik.ru/images/img_8.png" width="180" height="120" alt="img" />
					</div>
					<div class="services_desc">
						<a href="/stomotologiya/" class="services_link">Стоматология</a>
						<div class="services_title">Услуги специалистов:</div>
						<ul class="services_list">
							<li><a href="#">Острые боли,</a> <a href="#">лечение кариеса</a></li>
							
							<li><a href="#">Удаление зубов</a></li>
							
							<li><a href="#">Имплантация зубов</a></li>
							
							<li><a href="#">Протезирование зубов,</a> <a href="#">отбеливание зубов</a></li>
						</ul>
					</div>
				</td>
			</tr>
			<tr>
				<td>
					<div class="services_img">
						<img src="http://www.med-klinik.ru/images/img_9.png" width="180" height="120" alt="img" />
					</div>
					<div class="services_desc">
						<a href="#" class="services_link">Консультация терапевта</a>
						<div class="services_title">Услуги специалистов:</div>
						<ul class="services_list">
							<li><a href="#">Лечение гриппа,</a> <a href="#">вирусная инфекция (ОРВИ)</a></li>
							
							<li><a href="#">Лечение ОРЗ,</a> <a href="#">головные боли</a></li>
							
							<li><a href="#">Бронхит,</a> <a href="#">тонзелит,</a> <a href="#">трахеит</a></li>
						</ul>
					</div>
				</td>
				<td>
					<div class="services_img">
						<img src="http://www.med-klinik.ru/images/img_10.png" width="180" height="120" alt="img" />
					</div>
					<div class="services_desc">
						<a href="/klinicheskii--psiholog/" class="services_link">Клинический психолог</a>
						<div class="services_title">Услуги специалистов:</div>
						<ul class="services_list">
							<li><a href="#">Нарушение сна,</a> <a href="#">общие невротические состояния</a></li>
							
							<li><a href="#">Депрессивное состояние</a></li>
							
							<li><a href="#">Патопсихологическая диагностика для ГИБДД с выдачей заключения</a></li>
							
						</ul>
					</div>
				</td>
			</tr>
			<tr>
				<td>
					<div class="services_img">
						<img src="http://www.med-klinik.ru/images/img_11.png" width="180" height="120" alt="img" />
					</div>
					<div class="services_desc">
						<a href="/uzi/" class="services_link">УЗИ</a>
						<ul class="services_list">
							<li><a href="/uzi-ginekologicheskoye/">Гинекология,</a> <a href="/uzi-urologicheskoe/">урология,</a> <a href="/uzi-po-beremennosti/">УЗИ при беременности,</a> <a href="/uzi-organov-malogo-taza/">узи органов малого таза</a></li>
							
							<li><a href="/uzi-organov-bryushnoy-polosti/">УЗИ брюшной полости,</a> <a href="/molochnye-zhelezy/">УЗИ молочной железы,</a> <a href="#">УЗИ щитовидной железы</a></li>
						</ul>
					</div>
				</td>
				<td>
					<div class="services_img">
						<img src="http://www.med-klinik.ru/images/img_12.png" width="180" height="120" alt="img" />
					</div>
					<div class="services_desc">
						<a href="/sdat-analizy/" class="services_link">Анализы </a>
						<ul class="services_list">
							<li><a href="/analizy-na-polovyye-infektsii/">Анализы на половые инфекции,</a> <a href="/analizy-na-infektsii-u-muzhchin/">анализы на инфекции у мужчин,</a> <a href="/analizy-na-infekcii-u-zhenshchin/">анализы на инфекции у женщин,</a> <a href="/analizy-na-gormony/">анализы на гармоны,</a> <a href="/obsledovaniye-na-ippp/">ПЦР диагностика</a></li>
							
							<li><a href="/analizy-krovi/">Анализ крови,</a> <a href="/analiz-mochi/">анализ мочи,</a> <a href="/mikroskopiya/">микроскопия крови,</a> <a href="/mikrobiologiya/">микробиологические исследования,</a> <a href="/citologiya/">цитологическое исследование,</a> <a href="/gistologiya/">гистология</a></li>
							
						</ul>
					</div>
				</td>
			</tr>
		</table>
		
		<div class="slider_desc">
		
			<div class="slider_left">
				
				<ul class="bxslider_left">
					<li><img src="http://www.med-klinik.ru/images/fot_1.png" width="342" height="295" alt="Входная группа" /></li>
					<li><img src="http://www.med-klinik.ru/images/fot_2.png" width="342" height="295" alt="Ресепшен" /></li>
										<li><img src="http://www.med-klinik.ru/images/fot_4.png" width="342" height="295" alt="Кабинет забора анализов" /></li>
					<li><img src="http://www.med-klinik.ru/images/fot_5.png" width="342" height="295" alt="Кабинет гинеколога" /></li>
					<li><img src="http://www.med-klinik.ru/images/fot_6.png" width="342" height="295" alt="Стоматологический кабинет" /></li>
				</ul><!--/bxslider_left-->
				
			</div><!--/slider_left-->
			
			<div class="desc">
			
				<h1>Медицинский центр на Авиамоторной</h1>
				
				<p>Открытие нашего центра состоялось в 1998 году. А в 2012 году открылся медицинский центр на Авиамоторной. Мы пользуемся самым современным диагностическим оборудованием для оказания  медуслуг и оборудованием для лечения, чтобы медицинские услуги, оказанные нами, были на самом высоком уровне. В нашем клинике работают настоящие профессионалы, специалисты высочайшего класса, готовые оказать услуги лечения и диагностики профессионально и тактично: врачи высшей категории, кандидаты наук и доктора наук. В нашем медицинском центре ведут прием и оказывают услуги такие специалисты: акушеры-гинекологи, урологи, дерматологи, терапевты и врачи других специальностей.</p>
				
				<p>Мы поможем решить любые ваши медицинские проблемы.</p>
				
				<p>Обращайтесь к нам, и мы начнем решать ваши медицинские проблемы и оказание медуслуг сразу,<br /> 
как только Вам потребуется помощь!</p>

				<p>Вас приятно удивит атмосфера в нашем мед. центре, индивидуальный подход в лечении и оказании медуслуг. Услуги оказываются профессионально и на высоком уровне.<br />
Будьте здоровы!</p>
			
			</div><!--/desc-->
		
		</div><!--/slider_desc-->
		
		<div class="info">
		
			<p>Если Вам необходима <a href="/konsultatsiya-ginekologa-v-moskve/">консультация гинеколога</a>, <a href="/konsultatsiya-androloga/">консультация андролога</a>, <a href="/konsultacia_urologa/">консультация уролога</a> или других специалистов, обращайтесь в наш медицинский центр. Получить информацию по вопросам оказания услуг можно по телефону или записаться на прием к врачу прямо на сайте:</p>
			
			<div class="btn_zapis_wrap">
				<a href="/zayavka/" class="btn_zapis">Онлайн запись на прием</a>
			</div>
			
			<div class="phone_info">Звоните прямо сейчас! +7 (495) 256-38-00</div>
		
		</div><!--/info-->
		
		<div class="title_blue">Справочник инфекций</div>
		
		<div class="spravochnik">
		
			<div class="spravochnik_img">
				<img src="http://www.med-klinik.ru/images/img_14.png" width="173" height="130" alt="img" />
			</div>
			
			<div class="spravochnik_links">
			
				<ul class="services_list">
			
					<li><a href="/lechenie-i-diagnostika-infektsii/">Лечение и диагностика инфекций,</a> <a href="/klinika-trihomoniaza/">клиника трихомониаза,</a> <a href="/zarazhenie-trihomoniazom/">заражение трихомониазом,</a> <a href="/etiologiya-trihomoniaza/">этиология трихомониаза</a></li>
					
					<li><a href="/disseminirovannaya-gonokokkovaya-infekciya/">Дессеменированная гонококковая инфекция,</a> <a href="/klinika-papillomavirusa/">клиника папилломавируса,</a> <a href="/epidemiologiya-papillomavirusa/">эпидемилогия папилломавируса,</a> <a href="/etiologiya-papillomavirusa/">этиология папилломавируса</a></li>
					
					<li><a href="/hlamidiinaya-infekciya-u-detei/">Хламидийная инфекция у детей,</a> <a href="/hlamidioz-u-beremennyh/">хламидиоз у беременных,</a> <a href="/epidemiologiya-hlamidioza/">эпидемиология хламидиоза,</a> <a href="/etiologiya-hlamidioza/">этиология хламидиоза,</a> <a href="/simptomatika/">симптоматика</a></li>
					
					<li><a href="/bolezn-reitera/">Болезнь рейтера</a></li>
					
				<li><a href="/klinika-vpg/">Клиника ВПГ</a> <a href="/patogenez-vpg/">патогенез ВПГ</a></li>
				
				</ul>
				
			</div><!--/spravochnik_links-->
			
		</div><!--/spravochnik-->
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="js/bxslider.js"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
<script type="text/javascript" src="js/custom.js"></script>

</body>
</html>