$(function(){
	$('.bxslider').bxSlider({
        mode: 'fade',
        pager: true,
		controls: true,
		nextText: 'Next',
		prevText: 'Prev',
		auto: true,
		pause: 10000
	});
	$('.bxslider_left').bxSlider({
        mode: 'fade',
        pager: true,
		controls: true,
		nextText: 'Next',
		prevText: 'Prev',
		auto: true,
		pause: 4000
	});
	$('.lic a').lightBox();
});
	$(".form_zayavka").validate({
        
       rules:{ 
        
            name:{
                required: true,
                minlength: 3,
                maxlength: 20,
            },
            
            phone:{
                required: true,
                minlength: 9,
                maxlength: 11,
            },
       },
    });