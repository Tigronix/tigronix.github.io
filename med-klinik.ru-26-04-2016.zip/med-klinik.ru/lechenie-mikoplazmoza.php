﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Лечение микоплазмоза - цены, симптомы, схемы лечения, запись на прием | Медицинский центр на Авиамоторной</title>
<meta name="description" lang="ru" content="Лечение и диагностика микоплазмоза в медклинике на Авиамоторной. Анализы методом ПЦР от 240 рублей. Лечебное сопровождение при прохождении курса лечения от 2500 рублей. Запись на прием к врачу:  +7 (495) 256-38-00" />
<meta name="keywords" lang="ru" content="Лечение микоплазмоза" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/priem-dermatologa/">Консультация венеролога</a></li> <li>Микоплазмоз</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
			
	        		<h1>Микоплазмоз</h1>
					
					<p>Четких симптомов урогенитального микоплазмоза не существует. В 40% случаев болезнь протекает в скрытой форме. Бессимптомная форма встречается у 10-80% сексуально активных лиц детородного возраста. Как правило, отмечается развитие таких патогенных микроорганизмов, как хламидии, вирус простого герпеса, гарднереллы и трихомонады. При отсутствии комплексного подхода при профилактике микоплазмоза, как и при самолечении микоплазмоза, происходит развитие восходящего инфицирования, которое затрагивает органы мочевыделительной системы, малого таза, центральную нервную систему, суставы, легкие. Часто одним из иммунопатологических осложнений является синдром Рейтера.</p>
					
					<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>
<h2>Прием ведут:</h2>

<table class="tbl_spec tbl_spec_2">
			<tbody><tr>
				<td width="419">
						<img src="../images/foto_2.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Алексеев<br>
							Александр<br>
							Львович
						</div>
						<div class="tbl_spec_dolj">Уролог, андролог, сексолог, <br>врач высшей категории</div>
						<a href="/alekseev-aleksandr-lvovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
				<td width="417">
						<img src="../images/foto_3.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Диденко<br>
							Елена<br>
							Юрьевна
						</div>
						<div class="tbl_spec_dolj">Дерматовенеролог, уролог, андролог.<br>Врач 1 категории</div>
						<a href="/didenko-elena-yurevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
			<tr>
			
			<td>
						<img src="../images/foto_5.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Хмелевский<br>
							Игорь<br>
							Станиславович
						</div>
						<div class="tbl_spec_dolj">Уролог-андролог. <br>Врач 1 категории</div>
						<a href="/hmelevskii-igor-stanislavovich/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					<td>
						<img src="../images/foto_8.png" width="165" height="186" alt="img">
					<div class="tbl_spec_fio">
						Шиленина<br>
						Елена<br>
						Николаевна
					</div>
					<div class="tbl_spec_dolj">Акушер-гинеколог, <br>врач высшей категории</div>
					<a href="/shilenina-elena-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
			</tr>
			<tr>
				<td>
						<img src="../images/foto_4.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Букинская<br>
							Елена<br>
							Владимировна
						</div>
						<div class="tbl_spec_dolj">Акушер-гинеколог, врач <br>высшей категории</div>
						<a href="/bukinskaya-elena-vladimirovna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					<td>
						<img src="../images/foto_7.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Петрашко<br>
							Татьяна<br>
							Николаевна
						</div>
						<div class="tbl_spec_dolj">Врач акушер гинеколог, <br>врач высшей категории</div>
						<a href="/petrashko-tatyana-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
				
			</tr>
		</tbody></table>

<h2>Стоимость услуг:</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>

	<tbody>
		
		<tr>
			<td>Прием гинеколога (первичная консультация)</td>
			<td align="center" class="price"><span class="red_txt">1 000</span> </td>
		</tr>
		<tr>
			<td>Прием гинеколога(повторная консультация)</td>
			<td align="center" class="price">800</td>
		</tr>
		<tr>
			<td>Исследование мазков на флору</td>
			<td align="center" class="price">450</td>
		</tr>
		<tr>
			<td>Прием дерматовенеролога</td>
			<td align="center" class="price">1 500</td>
		</tr>
		<tr>
			<td>Прием дерматовенеролога с назначением лечения</td>
			<td align="center" class="price">3000</td>
		</tr>
		<tr>
			<td>Мазок из уретры</td>
			<td align="center" class="price">450</td>
		</tr>
		<tr>
			<td>Мазок отпечаток</td>
			<td align="center" class="price">450</td>
		</tr>
		<tr>
			<td>Лечение микоплазмоза(лечебное сопровождение</span>)</td>
			<td align="center" class="price">от 2 500</td>
		</tr>
		<tr>
			<td>Анализы на МИКОПЛАЗМОЗ</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>Микоплазмоз (Mycoplasma hominis)(кач)</td>
			<td align="center" class="price">240</td>
		</tr>
		<tr>
			<td>Микоплазмоз (Mycoplasma hominis)(кол)</td>
			<td align="center" class="price">440</td>
		</tr>
		<tr>
			<td>Микоплазмоз (Mycoplasma genitalis)(кач)</td>
			<td align="center" class="price">240</td>
		</tr>
		<tr>
			<td>Микоплазмоз (Mycoplasma genitalis)(кол)</td>
			<td></td>
		</tr>
		<tr>
			<td>Хламидофилы и микоплазмы(кач)</td>
			<td align="center" class="price">710</td>
		</tr>
		<tr>
			<td valign="top">&nbsp;</td>
			<td></td>
		</tr>
	</tbody>
</table>




<p>Возбудителями при микоплазмозе являются микроорганизмы Ureaplasma urealiticum, Mycoplasma genitalium, Mycoplasma hominis. Они не имеют клеточной стенки и занимают промежуточное положение между вирусами и бактериями. Микоплазмы условно-патогенны, то есть вызывают воспалительные заболевания урогенитального тракта только при определенных условиях и обычно с другими условно-патогенными или патогенными микроорганизмами. Носитель микоплазм является источником инфекции. Период инкубации составляет от 5-7 дней до 6 недель. Как правило, заражение происходит половым путем и от матери к плоду при беременности или во время родов в процессе прохождения ребенка по родовому каналу.</p>

<p><img class="img_center" style="width: 375px; height: 430px; margin: 10px;" src="../img/mycoplasma1.jpg" alt="лечение микоплазмоза - строение микоплазмы" /></p>

<div class="clr"></div>

<p><span class="bold">Специалисты «Клиники на Авиамоторной» предлагают профессиональные медицинские услуги, если Вам необходимо лечение такого заболевания как микоплазмоз</span></p>

<h2>Симптомы:</h2>

<p><img style="width: 250px; height: 167px; margin: 10px 20px; float: left;" src="../img/simptomy-mikoplazmy-genitalium.jpg" alt="симптомы микоплазмоза" /></p>



<ul class="spisok">
	<li>Жжение и болевые ощущения при мочеиспускании.</li>
	<li>Выделения из мочеиспускательного канала.</li>
	<li>У мужчин – симптомы простатита при поражении предстательной железы.</li>
	<li>У женщин – боль внизу живота при воспалении придатков и матки.</li>
</ul>


<div class="clr"></div>
<h2>Процедуры</h2>

<p>Процедура лечения в основном проводится антибиотиками. Подобрать при профилактики микоплазмоза препарат и дозу приема может только квалифицированный врач! Также используются противогрибковые препараты, витамины и иммуностимуляторы для укрепления иммунитета, пробиотики для восстановления микрофлоры. Самостоятельно применение препаратов может привести к осложнениям заболевания.</p>

<p><span class="bold">У женщин.</span> Помимо вышеуказанных средств, комплекс лечения включает использование вагинальных свечей с антибиотиками. По окончании терапии женщина должна пройти контрольную диагностику. Через определенное количество дней после окончания лечения, установленное врачом, проводится микроскопическое и культуральное исследование. Данная процедура обычно проводится трижды в течение каждого следующего менструального цикла. Если все три результата исследований являются отрицательными, курс терапии отменяется.</p>

<p><span class="bold">У мужчин.</span> К общим принципам лечения добавляются кремы и мази с содержанием антибактериальных веществ. По окончании терапии мужчины должны пройти контрольную диагностику. Для проверки наличия микоплазмы в организме может использоваться любой метод лабораторного исследования.</p>

<h2>Осложнения</h2>

<p><span class="bold">Заболевания мочевыделительной системы.</span> Заболевание у женщин является частой причиной возникновения воспалительных процессов малого таза. В связи с отсутствием комплексной терапии заболевание может вызвать хронический или острый сальпингит, эндометрит, аднексит, параметрит и т.д.</p>

<p><span class="bold">Осложнения беременности и родов.</span> Заболевание становится причиной спаек и воспалений маточных труб, что приводит к бесплодию и повышает риск внематочной беременности. При отсутствии лечения заболевание может вызвать преждевременные роды или формирование внутриутробных инфекций.</p>

<p><span class="bold">Возникновение бесплодия.</span> У мужчин инфекция влияет на сперматогенез, то есть развитие и образование сперматозоидов, а также на двигательные функции сперматозоидов. При отсутствии комплексного лечения заболевания это может привести к возникновению бесплодия.</p>

<p><span class="bold">Несвоевременное обращение к врачу  может стать причиной бесплодия! </span></p>

<p>Чтобы получить профессиональные консультации специалистов «Клиники на Авиамоторной» или записаться на прием к врачу, позвоните по телефону <span class="bold">+7 (495) 256-38-00</span>.</p>

		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li><a href="/priem-dermatologa/">Консультация венеролога</a>
		</li>
	<li><a href="/diagnostika-kandidoza/">Кандидоз</a>, 
		<a href="/lecheniye-kandidoza-v-moskve/">Лечение кандидоза</a>, 
		<a href="/epidemiologiya-kandidoza/">Эпидемиология кандидоза</a>, 
		<a href="/klinika-kandidoza/">Клиника кандидоза</a>
		</li>
	<li><a href="/lecheniye-khlamidioza-v-moskve/">Хламидиоз</a>, 
		<a href="/diagnostika-khlamidioza/">Диагностика хламидиоза</a>, 
		<a href="/lecheniye-khlamidioza-u-zhenshchin/">Лечение хламидиоза у женщин</a>, 
		<a href="/lecheniye-khlamidioza-u-muzhchin/">Лечение хламидиоза у мужчин</a>
		</li>
	<li><a href="/diagnostika-gerpesa/">Генитальный герпес</a>, 
		<a href="/lecheniye-genitalnogo-gerpesa/">Лечение генитального герпеса</a>, 
		<a href="/etiologiya-gerpesa/">Этиология герпеса</a>
		</li>
	<li><a href="/lecheniye-ureaplazmoza-u-zhenshchin/">Уреаплазмоз</a>
		</li>
	<li><a href="/lecheniye-papillomavirusa/">Папилломавирус</a>, 
		<a href="/diagnostika-vpch/">Диагностика ВПЧ</a>
		</li>
	<li><a href="/lechenie-trihomoniaza/">Трихомониаз</a>, 
		<a href="/diagnostika-trikhomoniaza/">Диагностика трихомониаза</a>
		</li>
	<li><a href="/lecheniye-gonorei/">Гонорея</a>, 
		<a href="/diagnostika-gonorei/">Диагностика гонореи</a>, 
		<a href="/lecheniye-gonorei-u-muzhchin/">Лечение гонореи у мужчин</a>, 
		<a href="/lecheniye-gonorei-u-zhenshchin/">Лечение гонореи у женщин</a>, 
		<a href="/gonoreya-u-detei/">Гонорея у детей</a>, 
		<a href="/etiologiya-gonorei/">Этиология гонореи</a>
		</li>
	<li><a href="/sifilis/">Сифилис</a>, 
		<a href="/etiologiya-sifilisa/">Этиология сифилиса</a>, 
		<a href="/puti-zarazheniya/">Пути заражения</a>, 
		<a href="/pervichnyi-period-sifilisa/">Первичный период сифилиса</a>, 
		<a href="/vtorichnyi-period-sifilisa/">Вторичный период сифилиса</a>, 
		<a href="/tretichnyi-period-sifilisa/">Третичный период сифилиса</a>, 
		<a href="/skrytyi-sifilis/">Скрытый сифилис</a>, 
		<a href="/neirosifilis/">Нейросифилис</a>, 
		<a href="/viscerosifilis/">Висцеросифилис</a>, 
		<a href="/vrozhdennyi-sifilis/">Врожденный сифилис</a>, 
		<a href="/diagnostika-sifilisa/">Диагностика сифилиса</a>
		</li>
	<li>
		<a href="/vich/">ВИЧ</a>
	</li>	
</ul>

</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>