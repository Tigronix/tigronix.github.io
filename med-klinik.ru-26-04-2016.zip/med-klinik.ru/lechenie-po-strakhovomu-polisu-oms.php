﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Лечение по страховому полису ОМС</title>
<meta name="description" lang="ru" content="" />
<meta name="keywords" lang="ru" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li>
<li>Лечение по страховому полису ОМС</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
		<h1>Лечение по страховому полису ОМС</h1>
		
		<p>Медицинский центр «Логон» на Авиамоторной входит в реестр организаций, имеющих право оказывать медицинскую помощь гражданам при предъявлении полиса ОМС (обязательного медицинского страхования).</p>
		
<p>УВАЖАЕМЫЕ ПАЦИЕНТЫ!</p>

<p>Наш медицинский центр в 2016 году участвует в городской программе оказания медицинских услуг по полису ОМС (обязательного медицинского страхования).</p>

<p>С 2016 года мы сможем предложить Вам следующие услуги по полису ОМС:</p>

<ul class="list">
	<li>Прием врача-терапевта (по полису ОМС).</li>
	<li>Прием врача-невролога (по полису ОМС).</li>
	<li>Прием врача-отоларинголога (по полису ОМС).</li>
	<li>Прием врача-гинеколога (по полису ОМС).</li>
	<li>Прием врача-уролога (по полису ОМС).</li>
	<li>Стоматология терапевтическая (по полису ОМС).</li>
</ul>

<p>О расширении спектра услуг по ОМС мы будем сообщать дополнительно в разделе новостей.</p>

<p>Данные услуги мы будем оказывать в отделении на Авиамоторной.</p>

</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>
