﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Нарушение менструального цикла</title>
<meta name="description" lang="ru" content="Нарушение менструального цикла" />
<meta name="keywords" lang="ru" content="Нарушение менструального цикла" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/konsultatsiya-ginekologa-v-moskve/">Консультация гинеколога</a></li> <li>Нарушение менструального цикла</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
			
	        		<h1>Нарушение менструального цикла</h1>
					
					<p>Нарушения менструального цикла могут вызывать как различные осложнения, так и серьезные заболевания, вплоть до не вынашивания беременности, бесплодия, рака.</p>

<div class="zapis_txt">
			Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
		</div>
		
		<h2>Прием ведут:</h2>

		<table class="tbl_spec tbl_spec_2">
				<tr>
					<td>
						<img src="../images/foto_4.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Букинская<br>
							Елена<br>
							Владимировна
						</div>
						<div class="tbl_spec_dolj">Акушер-гинеколог, врач <br>высшей категории</div>
						<a href="/bukinskaya-elena-vladimirovna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					<td>
						<img src="../images/foto_7.png" width="165" height="186" alt="img">
						<div class="tbl_spec_fio">
							Петрашко<br>
							Татьяна<br>
							Николаевна
						</div>
						<div class="tbl_spec_dolj">Врач акушер гинеколог, <br>врач высшей категории</div>
						<a href="/petrashko-tatyana-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
					</td>
					
					</tr>
					<tr>
				<td class="center_td">
					<img src="../images/foto_8.png" width="165" height="186" alt="img">
					<div class="tbl_spec_fio">
						Шиленина<br>
						Елена<br>
						Николаевна
					</div>
					<div class="tbl_spec_dolj">Акушер-гинеколог, <br>врач высшей категории</div>
					<a href="/shilenina-elena-nikolaevna/" class="tbl_spec_more">Онлайн консультация</a>
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>
		



<h2>Стоимость услуг:</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>

	<tbody>
		<tr>
			<td colspan="4">Гинекология</td>
		</tr>
		<tr>
			<td>Прием врача</td>
			<td class="price">1 000</td>
		</tr>
		<tr>
			<td>Гормоны</td>
			<td class="price">420</td>
		</tr>
		<tr>
			<td>Назначение лечения</td>
			<td class="price">от 2 500</td>
		</tr>
	</tbody>
</table>




<p><span class="bold">Существуют такие этапы менструальных нарушений:</span></p>

<ul class="list">
	<li>Альгодисменорея (болезненный менструальный цикл) – наблюдается примерно у половины женщин и встречается чаще, нежели другие нарушения менструального цикла. При таком нарушении болит низ живота, голова, тошнота, рвота, слабость, такое состояние может быть от нескольких часов до нескольких дней.</li>
	<li>Дисменорея – это нарушение нестабильности менструального цикла, месячные могут, как раньше начинаться, так и задерживаться</li>
	<li>Олигоменорея – это нарушение, когда месячные идут менее двух уток и имеют скудный характер</li>
	<li>Аменорея – это нарушение, когда месячные вообще отсутствуют в течение нескольких циклов подряд.</li>
</ul>

<p>Физиологическая аменорея характерна у беременных, девочек, не достигших полового созревания, женщин кормящих грудью и менопаузе.</p>

<p>При каких – либо нарушениях необходимо обратится вовремя к врачу и пройти осмотр, ведь чем раньше вы обратитесь со своей проблемой к профессионалу, тем легшее избежать осложнений, поэтому гинекологический осмотр необходимо проходить каждые полгода, даже если вас ничего не беспокоит.</p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
<li><a href="/vedenie-beremennosti-ceny/">Беременность</a>, 
	<a href="/lecheniye-bakterialnogo-vaginoza/">Вагиноз</a>, 
	<a href="/bartolinit/">Бартолинит</a>, 
	<a href="/salpingooforit-adneksit/">Аднексит</a>, 
	<a href="/endometrit-metroendometrit/">Эндометрит</a>, 
	<a href="/endocervicit/">Эндоцервицит</a>, 
	<a href="/endometrioz/">Эндометриоз</a>, 
	<a href="/eroziya-sheiki-matki/">Эрозия шейки матки</a>, 
	<a href="/infekcii-zhenskoi-polovoi-sistemy/">Инфекции женской половой системы</a>, 
	<a href="/proyavlenie-gormonalnyh-narushenii/">Гормональные нарушения</a>, 
	<a href="/diagnostika-besplodiya/">Бесплодие</a>, 
	<a href="/klimaks/">Климакс</a>, 
	<a href="/kontracepciya/">Контрацепция</a>, 
	<a href="/medikomentoznyi-abort/">Медикаментозный аборт </a>
</li>
<li><a href="/diagnostika-bakterialnogo-vaginoza/">Диагностика бактериального вагиноза</a>, 
	<a href="/etiologiya-bakterialnogo-vaginoza/">Этиология бактериального вагиноза</a>, 
	<a href="/zarazhenie-bakterialnym-vaginozom/">Заражение бактериальным вагинозом</a>, 
	<a href="/klinika-bakterialnogo-vaginoza/">Клиника бактериального вагиноза</a>, 
	<a href="/bakterialnyi-vaginoz-oslozhneniya/">Бактериальный вагиноз - осложнения </a>
</li>
<li><a href="/prichiny-gormonalnyh-narushenii/">Причины гормональных нарушений</a>, 
	<a href="/lechenie-i-diagnostika-gormonalnyh-narushenii/">Лечение и диагностика гормональных нарушений </a>
</li>
<li><a href="/lecheniye-besplodiya-v-moskve/">Лечение бесплодия</a>, 
	<a href="/lecheniye-zhenskogo-besplodiya/">Лечение женского бесплодия</a>
</li>
<li>
	<a href="/farmabort/">Фармаборт</a>, 
	<a href="/bezoperacionnyi-abort/">Безоперационный аборт</a>, 
	<a href="/abort-tabletkami/">Аборт таблеткам</a>
</li>

</ul>

</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>