﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Сдать анализы в Москве недорого, цены: срочно, платно - стоимость анализов</title>
<meta name="description" lang="ru" content="Анализы" />
<meta name="keywords" lang="ru" content="Анализы" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li>Анализы</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside2.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
			
	        		<h1>Все виды анализов в одном месте: медклиника на Авиамоторной</h1>


<p>Сегодня срочная платная сдача анализов в Москве в медицинском центре «Логон» является наилучшим вариантом выявления малейших отклонений в состоянии 
своего организма и оперативно решить проблемы со здоровьем. В многопрофильной лаборатории нашей клиники выполняется более 100 различных анализов, включая 
самые редкие. Здесь вы можете сдать общие и развернутые анализы крови на вирусы, инфекции, гормоны, сахар, сделать ПЦР-диагностику, пройти обследование на 
ИППП и многие другие исследования, и уже в течение дня узнать достоверный результат.</p>

			<h2>Сдать анализы в Москве: срочно и без очереди! Наш адрес:</h2>
			<ul class="address_list">
				<li>Москва, шоссе Энтузиастов, д. 11, к. 1 (5 мин от метро Авиамоторная). <br />Телефон: +7 (495)256-38-00</li>
			</ul>

<h2>Популярные виды анализов:</h2>

<ul class="address_list">
<li><a href="/analiz-mochi/">Анализ мочи</a></li>
<li><a href="/analizy-krovi/">Анализы крови</a></li>
<li><a href="/analizy-na-infektsii-u-muzhchin/">Анализы на инфекции у мужчин</a></li>
<li><a href="/analizy-na-gormony/">Анализы на гормоны</a></li>
</ul>


<p style="margin-top:5px;"><b>Почему нам доверяют?</b></p>
<ul>
<li>Своим пациентам мы предоставляем широкий спектр медицинских услуг: от выполнения анализов крови, мочи, кала и других биоматериалов до комплексного 
лечения и профилактики заболеваний по урологии, венерологии, дерматологии, гинекологии и другим направлениям. </li>
<li>У нас работают опытные, высококвалифицированные доктора, которые на основе проведенных анализов смогут дать достоверную оценку состояния вашего 
здоровья и предоставить профессиональную помощь.</li>
<li>Лаборатория нашей клиники оснащена новейшим оборудованием, к тому же, для выполнения исследований используются только качественные реактивы ведущих 
производителей. </li>
<li>У нас вы можете сдать анализы анонимно и срочно.</li>
</ul>

<p>Если вы ищете, где в Москве можно сделать анализы по доступной цене, конфиденциально и быстро, тогда медицинский центр «Логон» к вашим услугам. Наша 
клиника работает ежедневно, поэтому вы можете записаться на прием на любой удобный для себя день. Всем пациентам предоставляется гибкая система скидок, 
поэтому стоимость анализов у нас дешевле, чем в других клиниках. Обратившись к нам, вы без лишних затрат, хлопот и очередей получите квалифицированную 
медицинскую помощь в Москве!</p>



<p><a href="/analizy-anonimno/">Анализы анонимно</a></p>



<p><a href="/analizy-na-polovyye-infektsii/">Анализы на половые инфекции</a></p>



<p><a href="/obsledovaniye-na-ippp/">Обследование и анализы на ИППП</a></p>

	        	
		
		

</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>