﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Карта</title>
<meta name="description" lang="ru" content="Анализы" />
<meta name="keywords" lang="ru" content="Анализы" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="http://www.med-klinik.ru/css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="#">Главная</a></li>
<li>Карта</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside2.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
			<h1>Сдать анализы:</h1>
			
			<ul>
			
				<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/baumanskaya/">Бауманская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/belorusskaya/">Белорусская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/borisovo/">Борисово</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/bratislavskaya/">Братиславская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/chkalovskaya/">Чкаловская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/dobryninskaya/">Добрынинская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/dubrovka/">Дубровка</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/elektrozavodskaya/">Электрозаводская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/izmaylovskaya/">Измайловская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/kievskaya/">Киевская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/komsomolskaya/">Комсомольская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/kotelniki/">Котельники</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/kozhuhovskaja/">Кожуховская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/krasnopresnenskaya/">Краснопресненская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/krestyanskaya-zastava/">Крестьянская застава</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/kurskaya/">Курская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/kuzminki/">Кузьминки</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/lermontovskiy-prospekt/">Лермонтовский проспект</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/lyublino/">Люблино</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/marksistskaya/">Марксистская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/maryino/">Марьино</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/novokosino/">Новокосино</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/novoslobodskaya/">Новослободская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/oktiabrskaya/">Октябрьская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/park-kultury/">Парк Культуры</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/partizanskaya/">Партизанская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/paveletskaya/">Павелецкая</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/pechatniki/">Печатники</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/perovo/">Перово</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/pervomayskaya/">Первомайская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/proletarskaya/">Пролетарская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/prospekt-mira/">Проспект Мира</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/rimskaya/">Римская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/rjazanskij-prospekt/">Рязанский проспект</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/semenovskaya/">Семеновская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/shchelkovskaya/">Щелковская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/shipilovskaya/">Шипиловская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/shosse-entuziastov/">Шоссе Энтузиастов</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/taganskaya/">Таганская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/tekstilshchiki/">Текстильщики</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/tretyakovskaya/">Третьяковская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/volgogradskij-prospekt/">Волгоградский проспект</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/volzhskaya/">Волжская</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/vykhino/">Выхино</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/zhulebino/">Жулебино</a></li>
<li><a href="http://www.med-klinik.ru/sdat-analizy/metro/zyablikovo/">Зябликово</a></li>
			
			</ul>
			
		</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="http://www.med-klinik.ru/js/bxslider.js"></script>
<script type="text/javascript" src="http://www.med-klinik.ru/js/lightbox.js"></script>
<script type="text/javascript" src="http://www.med-klinik.ru/js/custom.js"></script>

</body>
</html>