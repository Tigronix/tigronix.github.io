﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Ультразвуковая диагностика</title>
<meta name="description" lang="ru" content="Ультразвуковая диагностика" />
<meta name="keywords" lang="ru" content="Ультразвуковая диагностика" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/uzi-po-beremennosti/">Акушерство</a></li> <li>Ультразвуковая диагностика</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
			
	        		<h1>Ультразвуковая диагностика</h1>
					
					
					
					<p>В настоящее время ультразвуковое исследование широко применяется в медицинской практике и позволяет своевременно обнаружить изменения во внутренних органах человека на самых ранних этапах заболевания. Новейшее оборудование (ультразвуковые сканеры Samsung Medison) , высокий профессионализм врачей и большой опыт работы позволяет поставить правильный диагноз, и помочь лечащему врачу определить правильную тактику лечения и контролировать его эффективность.</p>
<div class="zapis_txt">
	Записаться на прием и консультацию можно по телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
</div>

<div class="doc_info">
			
						<table class="tbl_doc_info">
							<tbody><tr>
								<td width="469">
									<img src="../images/foto_15.jpg" width="165" height="186" alt="img">
									<div class="tbl_spec_fio">
										Каримова <br />Галина <br />Михайловна
									</div>
									<div class="tbl_spec_dolj">Врач ультразвуковой диагностики, <br />врач высшей категории</div>
								</td>
								<td width="333" class="tbl_doc_info_right">
									<span class="bold">Записаться на прием можно:</span><br>
									
									На сайте:
									
									<div class="arrow_bot"></div>
									
									<span class="btn_zapis_wrap">
										<a href="/zayavka/" class="btn_zapis">Онлайн запись на прием</a>
									</span>
									<div class="tbl_doc_info_contact">
										По телефону: <span class="tbl_doc_info_phone">+7 (495) 256-38-00</span>
									</div>
								</td>
							</tr>
						</tbody></table>
					
			</div>

<h2>Стоимость услуг:</h2>

<table class="tbl_price">
<thead>
	<tr>
		<td width="603">Наименование услуги</td>
		<td width="197" align="center">Стоимость руб.</td>
	</tr>
</thead>
	<tbody>
		<tr>
			<td>ГИНЕКОЛОГИЯ:</td>
			<td></td>
		</tr>
		<tr>
			<td>Трансабдоминальное ( TA ) трансвагинальное  ( TV )</td>
			<td class="price">900 / 1 100</td>
		</tr>
		<tr>
			<td>Мониторинг яйцеклетки (ведение гинекологом)</td>
			<td class="price">1 500</td>
		</tr>
		<tr>
			<td>Фолликулометрия  1 обсл</td>
			<td class="price">500</td>
		</tr>
		<tr>
			<td>Молочные железы + рег. л/узлы</td>
			<td class="price">1 000</td>
		</tr>
		<tr class="tbl_price_thead">
			<td colspan="2">АКУШЕРСТВО:</td>
			</tr>
		<tr>
			<td>Беременность I трим   (до 10 недель)</td>
			<td class="price">1 100</td>
		</tr>
		<tr>
			<td>Беременность I трим   (скрининговое исследование 10-14 нед.)</td>
			<td class="price">1 500</td>
		</tr>
		<tr>
			<td>Беременность II трим  (14 -23 нед)</td>
			<td class="price">1 500</td>
		</tr>
		<tr>
			<td>Беременность II трим  (скрининговое исследование 18-20 нед.)</td>
			<td class="price">1 700</td>
		</tr>
		<tr>
			<td>Беременность III трим (24 – 39 нед)</td>
			<td class="price">1 900</td>
		</tr>
		<tr>
			<td>Беременность II-III трим c допплерографией</td>
			<td class="price">2 200</td>
		</tr>
		<tr>
			<td>Допплерография маточно-плацентарного кровотока</td>
			<td class="price">1 500</td>
		</tr>
		<tr>
			<td valign="top">&nbsp;</td>
			<td></td>
		</tr>
	</tbody>
</table>






<h2>В нашем медицинском центре Вы можете пройти</h2>

<ul class="list">
	<li>УЗИ брюшной полости;</li>
	<li>УЗИ малого таза у женщин ;</li>
	<li>УЗИ органов мошонки, предстательной железы;</li>
	<li>ТРУЗИ (трансректальное УЗИ);</li>
	<li>УЗИ щитовидной железы;</li>
	<li>УЗИ почек, надпочечников;</li>
	<li>УЗИ молочных желез, лимфоузлов;</li>
	<li>УЗИ мягких тканей</li>
	<li>УЗИ слюнных желез</li>
	<li>УЗИ с допплерографией сосудов;</li>
	<li>УЗИ при беременности I, II, III триместров (экспертное) и др.</li>
</ul>

<p style="font-weight: bold; text-align: justify;">Помните и не забывайте о своем здоровье!</p>

<p>УЗИ позволяет выявить даже самые минимальные нарушения в организме. И на самых ранних этапах тем самым свести к минимуму Ваши затраты на лечение.</p>

<p><span class="bold">Записаться на прием можно по телефону </span><span style="font-size:22px;">+7 (495) 256-38-00</span>.</span></p>

	        	
		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">
	<li><a href="/uzi/">Узи</a></li>

	<li><a href="/uzi-ginekologicheskoye/">Гинекология</a></li>

	<li><a href="/uzi-urologicheskoe/">Урология</a></li>

	<li><a href="/uzi-po-beremennosti/">Акушерство</a>, 
	<a href="/uzi-organov-malogo-taza/">УЗИ органов малого таза</a>, </li>
	<a href="/uzi-organov-bryushnoy-polosti/">УЗИ брюшной полости</a></li>

	<li><a href="/molochnye-zhelezy/">Молочные железы</a>, 
	<a href="/shchitovidnaya-zheleza/">Щитовидная железа</a></li>
</ul>

</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>