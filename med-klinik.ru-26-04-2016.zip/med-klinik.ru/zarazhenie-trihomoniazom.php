﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Заражение трихомониазом</title>
<meta name="description" lang="ru" content="Заражение трихомониазом" />
<meta name="keywords" lang="ru" content="Заражение трихомониазом" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="/favicon.ico" type="image/x-icon" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="top">

	<?php include("blocks/top.php"); ?>

</div><!--/top-->

<div class="container">

	<div class="header">
	
		<?php include("blocks/header.php"); ?>
	
	</div><!--/header-->
	
	<div class="content">
			
		<div class="title_blue">Внимание! Акция! При записи с сайта скидка на первичный прием 30%</div>
		
		<ul class="pw">
<li><a href="/">Главная</a></li> <li><a href="/spravochnik-infekcii/">Справочник инфекций</a></li> <li>Заражение трихомониазом</li></ul>
		
		<div class="lside">
		
			<?php include("blocks/lside.php"); ?>
		
		</div><!--/lside-->
		
		<div class="rside_txt">
		
	        		<h1>Заражение трихомониазом</h1>

<p><span class="bold">Урогенитальные трихомонады</span> проникают в организм постепенно per continuitatem, через межклеточные пространства и затем в субэпителиальную соединительную ткань, а также лимфогенно через множественную сеть лимфатических щелей.</p>

<p>Трихомонады, попадая в уретру, фиксируются на клетках плоского эпителия слизистой оболочки, проникают в железы мочеиспускательного канала и лакуны. Попадая в мочеполовые органы, трихомонады либо обусловливают развитие воспаления, либо не вызывают никаких изменений. Умерено выраженная воспалительная реакция развивается при наличии большого количества паразитов. Выделяемая трихомонадами гиалуронидаза приводит к значительному разрыхлению тканей и более свободному проникновению в межклеточные пространства токсических продуктов обмена бактерий сопутствующей флоры.</p>

<h2>Патогенетические факторы трихомониаза:</h2>

<ul class="list">
	<li>интенсивность инфекционного воздействия;</li>
	<li>рН влагалищного и других секретов;</li>
	<li>физиологическое состояние эпителия мочеполовой системы;</li>
	<li>сопутствующая бактериальная флора.</li>
</ul>

<p><span class="bold">Трихомонадная инфекция</span> не приводит к развитию выраженного иммунитета. Иммунный ответ на паразитирование трихомонад изучен недостаточно. Выявляемые у больных или переболевших трихомониазом сывороточные и секреторные антитела являются лишь "свидетелями" существующей или ранее перенесенной инфекции, но не способны обеспечить иммунитет.<br>
<br>
Средняя частота инфицированности трихомониазом клинически здоровых женщин детородного возраста в различных странах и разных социально-демографических группах колеблется от 2-10% (США) до 15-40% (в тропических странах). По оценкам специалистов, в США ежегодно инфицируются 3 млн. женщин. При этом от 30 до 70% их партнёров мужчин заражаются трихомониазом транзиторно. У взрослых девственниц регистрируется нулевая заболеваемость. Она достигает 70% у проституток, у лиц с другими венерическими болезнями и у половых партнёров инфицированных больных. Чаще заболевают женщины в возрасте от 16 до 35 лет. Удельный вес урогенитального <a href="/lechenie-trihomoniaza/">трихомониаза</a> среди первичных негонорейных уретритов достигает 65-80%. Число зарегистрированных случаев трихомониаза в мире за 1995 год составляет 170 млн.<br>
<br>
Трихомонада мочеполовая передаётся при половом контакте. Хотя возбудитель сохраняет жизнеспособность в течение 24 часов в моче, сперме, а также в воде и может выживать в течение нескольких часов во влажном чистом белье, передача инфекции бытовым путём происходит редко. Возможность инфицирования женщин трихомониазом при купаниях в реках, плавательных бассейнах, а также в банях, в настоящее время полностью отвергается.</p>

		
		<h2>Смотрите так же:</h2>

<ul class="services_list services_list_2">

	<li><a href="/spravochnik-infekcii/">Справочник инфекций</a></li>

	<li>
	<a href="/lechenie-i-diagnostika-infektsii/">Лечение и диагностика инфекции</a>, 
	<a href="/klinika-trihomoniaza/">Клиника трихомониаза</a>, 
	<a href="/etiologiya-trihomoniaza/">Этиология трихомониаза</a>, 
	<a href="/disseminirovannaya-gonokokkovaya-infekciya/">Диссеминированная гонококковая инфекция</a>, 
	<a href="/klinika-papillomavirusa/">Клиника папилломавируса</a>, 
	<a href="/epidemiologiya-papillomavirusa/">Эпидемиология папилломавируса</a>, 
	<a href="/etiologiya-papillomavirusa/">Этиология папилломавируса</a>, 
	<a href="/hlamidiinaya-infekciya-u-detei/">Хламидийная инфекция у детей</a>, 
	<a href="/hlamidioz-u-beremennyh/">Хламидиоз у беременных</a>, 
	<a href="/simptomatika/">Симптоматика</a>, 
	<a href="/epidemiologiya-hlamidioza/">Эпидемиология хламидиоза</a>, 
	<a href="/etiologiya-hlamidioza/">Этиология хламидиоза</a>, 
	<a href="/klinika-vpg/">Клиника ВПГ</a>, 
	<a href="/patogenez-vpg/">Патогенез ВПГ</a>
	</li>

</ul>

</div><!--/rside_txt-->
		
		<div class="clr"></div>
	
	</div><!--/content-->
	
</div><!--/container-->
	
<div class="footer">

	<div class="footer_in">
	
		<?php include("blocks/footer.php"); ?>
	
	</div><!--/footer_in-->

</div><!--/footer-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="../js/bxslider.js"></script>
<script type="text/javascript" src="../js/lightbox.js"></script>
<script type="text/javascript" src="../js/custom.js"></script>

</body>
</html>